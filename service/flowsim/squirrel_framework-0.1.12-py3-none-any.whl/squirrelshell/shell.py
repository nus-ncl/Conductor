import cmd
import os
import hashlib
import subprocess
import readline
import shlex

import squirrel

from squirrel.interface.idapro.idapro_client import IDAProClient
from squirrel.squirrel_disassembler import SquirrelDisassemblerZydis

class SquirrelShell(cmd.Cmd):
    intro = "Welcome to Squirrel shell. Type help or ? to list commands.\n"
    prompt_str = "(squirrel)<{}>$ "
    bin_path = os.path.join(os.path.expanduser('~'), '.config', 'squirrel', 'binaries')
    cur_bin = None

    def _exists_bin(self, args):
        binaries = os.listdir(SquirrelShell.bin_path)

    def _get_bin_path(self, bin_info):
        bin_hash, bin_name = bin_info
        bin_dir = os.path.join(SquirrelShell.bin_path, bin_hash, 'binary')
        return os.path.join(bin_dir, os.listdir(bin_dir)[0])

    def preloop(self):
        self.prompt = SquirrelShell.prompt_str.format('')
        self.binaries = []
        self.idapro = None
        for bin_hash in os.listdir(SquirrelShell.bin_path):
            filename = os.listdir(os.path.join(SquirrelShell.bin_path, bin_hash, 'binary'))[0]
            self.binaries.append((bin_hash, filename))

    def postcmd(self, stop, line):
        file_str = ''
        if self.cur_bin:
            bin_hash, filename = self.cur_bin
            file_str = '{}({})'.format(bin_hash[:6], filename[:6])
        self.prompt = SquirrelShell.prompt_str.format(file_str)
        return stop

    def idapro_workon(self, args):
        if not self.cur_bin:
            print("Please load a binary first.")
            return False
        if not self.idapro:
            print("Please connect to IDAPro Server")
            return False
        bin_path = self._get_bin_path(self.cur_bin)
        status = self.idapro.workon_binary(bin_path)

    def idapro_connect(self, args):
        if self.idapro:
            print("IDAProClient has already been initialized.")
            return False
        hostname, port = shlex.split(args)
        port = int(port)
        self.idapro = IDAProClient(hostname, port)

    def idapro_daemon(self, args):
        if not self.idapro:
            print("Please connect to IDAPro Server")
            return False
        tokens = shlex.split(args)
        if len(tokens) != 1:
            print("Argument Error: {}".format(tokens))
        port = tokens[0]
        self.idapro.connect_daemon(None, port)

    def idapro_kill(self, args):
        self.idapro.idapro_daemon.remote_shutdown()
        self.idapro.idapro_daemon = None

    def help_idapro(self):
        return ''

    def idapro_getacorn_insns(self, args):
        if not self.idapro:
            print("Please connect to IDAPro Server")
            return False
        acorns = self.idapro.getacorn_insns()

    def idapro_insn_help(self):
        return ''

    def idapro_getacorn(self, args):
        tokens = shlex.split(args)
        if len(token) == 0:
            print(self.idapro_insn_help())
            return False
        sub_cmd = tokens[0].lower()
        if len(tokens) > 1:
            sub_args = ' '.join(tokens[1:])
        else:
            sub_args = ''
        if sub_cmd == 'insns':
            self.idapro_getacorn_insns(sub_args)



    def do_idapro(self, args):
        tokens = shlex.split(args)
        if len(tokens) == 0:
            self.help_idapro()
            return False
        sub_cmd = tokens[0].lower()
        if len(tokens) > 1:
            sub_args = ' '.join(tokens[1:])
        else:
            sub_args = ''

        if sub_cmd == 'connect':
            self.idapro_connect(sub_args)
        elif sub_cmd == 'workon':
            self.idapro_workon(sub_args)
        elif sub_cmd == 'status':
            print(self.idapro.idapro_server.list_daemons())
        elif sub_cmd == 'killall':
            daemons = self.idapro.idapro_server.list_daemons()
            for port in daemons:
                self.idapro_daemon(port)
                self.idapro_kill('')
        elif sub_cmd == 'daemon':
            self.idapro_daemon(sub_args)
        elif sub_cmd == 'kill':
            self.idapro_kill(sub_args)
        elif sub_cmd == 'getacorn':
            self.idapro_getacorn(sub_args)

    def do_clear(self, args):
        subprocess.call("clear")

    def do_list(self, args):
        list_line = "[{: >5}][{: >64}][{: >20}]"
        list_output = []
        list_output.append(list_line.format('*Idx*', 'SHA256 Hash'.center(64, '*'), 'Filename'.center(20, '*')))
        list_output.append('='*95)
        for idx, bin_tuple in enumerate(self.binaries):
            bin_hash, filename = bin_tuple
            list_output.append(list_line.format(idx, bin_hash, filename))
        list_output.append("{: >95}".format('Found {} binaries'.format(len(self.binaries)).center(95, '=')))
        print('\n'.join(list_output))

    def do_load(self, args):
        if len(args) < 64:
            # index argument
            idx = int(args)
            if idx < len(self.binaries):
                self.cur_bin = self.binaries[idx]
        else:
            if args in self.binaries:
                self.cur_bin = args
        if not self.cur_bin:
            print("Binary hash {} not found, please create it first!".format(args))

    def do_unload(self, args):
        if self.cur_bin:
            self.cur_bin = None

    def do_create(self, args):
        try:
            with open(args, 'rb') as f:
                file_data = f.read()
        except:
            print("Error opening file, please check {}.".format(args))
            return False

        sha256 = hashlib.sha256()
        sha256.update(file_data)
        bin_hash = sha256.hexdigest()

        if bin_hash in [x for x, _ in self.binaries]:
            print("Binary hash {} already exist!".format(bin_hash))
            return False

        filename = os.path.basename(args)

        bin_dir     = os.path.join(SquirrelShell.bin_path, bin_hash)
        acorn_dir   = os.path.join(bin_dir, 'acorns')
        binary_dir  = os.path.join(bin_dir, 'binary')

        os.makedirs(bin_dir)
        os.makedirs(acorn_dir)
        os.makedirs(binary_dir)

        binary_path = os.path.join(binary_dir, filename)

        with open(binary_path, 'wb') as f:
            f.write(file_data)

        self.binaries.append((bin_hash, filename))
        self.do_load(bin_hash)

    def complete_create(self, text, line, start_idx, end_idx):
        tokens = shlex.split(line)
        if len(tokens) != 2:
            return os.listdir('.')
        text = tokens[1]
        # match the last /, and get a list
        slash_idx = text.rfind('/')
        if slash_idx == -1:
            cur_dir = os.listdir('.')
        else:
            cur_dir = os.listdir(text[:slash_idx+1])
        incomplete = text[slash_idx+1:]
        return [x for x in cur_dir if x.startswith(incomplete)]

    def do_del(self, args):
        pass

    def do_bye(self, args):
        return True

def main():
    SquirrelShell().cmdloop()

if __name__ == "__main__":
    main()
