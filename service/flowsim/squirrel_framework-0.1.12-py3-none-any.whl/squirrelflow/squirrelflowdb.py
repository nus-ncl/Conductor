import configparser
import threading
import os
import queue
import json
import copy

from xmlrpc.server import SimpleXMLRPCServer
from xmlrpc.client import ProtocolError, Fault, ServerProxy

from sqlalchemy import create_engine, or_
from sqlalchemy.orm import sessionmaker, scoped_session

from squirrelflow.squirrelflowdb_common import *
from squirrel.squirrel import load_config

class SquirrelFlowDB(object):
    def __init__(self, config):
        engine = init_db(config['database_config'])
        self.session_factory = scoped_session(sessionmaker(bind=engine))
        self.work_queue = queue.Queue()
        self.working = []
        self.broken = []
        self.working_lock = threading.Lock()

        # init the workers
        print('Init workers')
        self.init_workers(config)

    def init_workers(self, config):
        ti_config = config['squirrelflowdb']
        save_obs_flag = config.getboolean('squirrelflowdb', 'save_obs')
        self.minions = []
        conn_strs = ti_config['remote_taintinduce'].split('\n')
        for conn_str in conn_strs:
            minion_thread = threading.Thread(target=minion, args=(conn_str,
                self.work_queue, (self.working, self.working_lock),
                self.session_factory, save_obs_flag))
            minion_thread.daemon = True
            self.minions.append(minion_thread)
        for x in self.minions:
            x.start()

    def check_rules(self, archstring, insn_list):
        session = self.session_factory()
        missing_rules = set()
        for bytestring in insn_list:
            rule_json = self.get_rule(archstring, bytestring)
            if not rule_json:
                missing_rules.add(bytestring)
        missing_rules = list(missing_rules)
        return missing_rules

    def _get_insninfo(self, archstring, bytestring):
        session = self.session_factory()
        insninfo_results = session.query(InsnInfoORM).filter_by(bytestring=bytestring, archstring=archstring)
        session.commit()
        if (insninfo_results.count() == 1):
            return insninfo_results.first()
        elif (insninfo_results.count() > 1):
            raise Exception()
        return None

    def get_rule(self, archstring, bytestring):
        insninfo_orm = self._get_insninfo(archstring, bytestring)
        if not insninfo_orm:
            return None
        if (len(insninfo_orm.rules) == 1):
            rule_str = insninfo_orm.rules[0].text
            return rule_str
        elif (insninfo_orm.rules.count() > 1):
            raise Exception()
        return None

    def get_working(self):
        self.working_lock.acquire()
        result = list(self.working)
        self.working_lock.release()
        return result

    def train_rules(self, archstring, insn_list):
        # queue the bytestrings to be trained
        added_list = []
        rejected_list = []
        working_list = self.get_working()
        for bytestring in insn_list:
            if ((archstring, bytestring)) not in working_list and not self.get_rule(archstring, bytestring):
                added_list.append(bytestring)
                self.working_lock.acquire()
                self.working.append((archstring, bytestring))
                self.working_lock.release()
                self.work_queue.put((archstring, bytestring))
            else:
                rejected_list.append(bytestring)
        return (added_list, rejected_list)


def minion(conn_str, work_queue, working_struct, session_factory,
        save_obs_flag=True):
    working, working_lock = working_struct
    print('Connecting to {}'.format(conn_str))
    try:
        ti_worker = ServerProxy(conn_str)
        ti_worker.test_connection()
    except Exception as e:
        print(e)
        return
    print('Connected to {}'.format(conn_str))
    while True:
        archstring, bytestring = work_queue.get()
        print('{}: Working on {}-{}'.format(conn_str, archstring, bytestring))
        try:
            insninfo_str, obs_str_list, rule_str = ti_worker.gen_obs_rule(archstring, bytestring)
        except ProtocolError as e:
            print(e)
            raise
        except Fault as e:
            err_str = '{} -- {} - {}'.format(e, archstring, bytestring)
            print('{} -- {} - {}'.format(e, archstring, bytestring))
            working_lock.acquire()
            working.remove((archstring, bytestring))
            with open('/tmp/broken.txt', 'a+') as broken_insn:
                broken_insn.write('{}\n'.format(err_str))
            working_lock.release()
            continue

        session = session_factory()
        insninfo_orm = InsnInfoORM(archstring=archstring, bytestring=bytestring,
                text=insninfo_str)
        insninfo_orm.rules.append(RuleORM(text=rule_str))
        if save_obs_flag:
            insninfo_orm.observations.extend([ObservationORM(text=x) for x in
                obs_str_list])
        session.add(insninfo_orm)
        session.commit()
        session_factory.remove()

        working_lock.acquire()
        working.remove((archstring, bytestring))
        working_lock.release()


def main():
    config = load_config('squirrelflow', 'squirrelflowdb.cfg')
    hostname = config['squirrelflowdb']['bind_hostname']
    port = int(config['squirrelflowdb']['bind_port'])
    print('Listning on {}:{}'.format(hostname, port))
    server = SimpleXMLRPCServer((hostname, port), allow_none=True)
    server.register_instance(SquirrelFlowDB(config))
    server.serve_forever()

if __name__ == "__main__":
    main()
