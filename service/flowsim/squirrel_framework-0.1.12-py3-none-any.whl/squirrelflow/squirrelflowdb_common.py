from sqlalchemy import create_engine
from sqlalchemy import Column, ForeignKey, Integer, String, Binary, LargeBinary, ForeignKey, Boolean
from sqlalchemy import Text, UniqueConstraint
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship

import configparser

from squirrel.squirrel import load_config

Base = declarative_base()

_MAX_TEXT = 4294967295

class InsnInfoORM(Base):
    __tablename__       = 'insninfo'
    __table_args__      = (UniqueConstraint('bytestring', 'archstring',
        name='uq_byte_arch_string'),)

    id                  = Column(Integer, primary_key=True, autoincrement=True)
    bytestring          = Column(String(255), nullable=False)
    archstring          = Column(String(255), nullable=False)
    text                = Column(Text(_MAX_TEXT)) 
    blob                = Column(LargeBinary()) 

    rules               = relationship('RuleORM', back_populates='insninfo')
    observations        = relationship('ObservationORM', back_populates="insninfo")

class RuleORM(Base):
    __tablename__   = 'rules'

    id              = Column(Integer, primary_key=True, autoincrement=True)
    insninfo_id     = Column(Integer, ForeignKey('insninfo.id'))
    text            = Column(Text(_MAX_TEXT))
    blob            = Column(LargeBinary())

    insninfo        = relationship('InsnInfoORM', back_populates='rules')

class ObservationORM(Base):
    __tablename__   = 'observations'

    id              = Column(Integer, primary_key=True, autoincrement=True)
    insninfo_id     = Column(Integer, ForeignKey('insninfo.id'))
    init_state      = Column(String(255))
    text            = Column(Text(_MAX_TEXT)) 
    blob            = Column(LargeBinary())

    insninfo        = relationship('InsnInfoORM', back_populates='observations')

def init_db(db_config, is_echo=False):
    db_name = 'squirrelflowdb'
    db_user = db_config['username']
    db_password = db_config['password']
    db_conn = db_config['connection']

    conn_string = 'mysql://{}:{}@{}/{}'.format(db_user, db_password, db_conn, db_name)
    engine = create_engine(conn_string, echo=is_echo)
    return engine

def main():
    config = load_config('squirrelflow', 'squirrelflowdb.cfg')
    engine = init_db(config['database_config'])
    #engine2 = create_engine("sqlite:///:memory:", echo=True)
    #print(Base.metadata.create_all(engine2))
    #return
    Base.metadata.create_all(engine)

if __name__ == "__main__":
    main()
