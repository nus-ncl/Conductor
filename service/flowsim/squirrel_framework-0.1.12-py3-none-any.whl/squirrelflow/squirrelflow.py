import configparser
import sys
import json
import argparse

from xmlrpc.client import ServerProxy

import squirrel.acorn.acorn as acorn

from squirrel.squirrel import load_config


class SquirrelFlow(object):
    def __init__(self, hostname, port):
        conn_str = 'http://{}:{}'.format(hostname, port)
        self.squirrelflowdb = ServerProxy(conn_str)

    def get_rule(self, archstring, bytestring):
        rule_string = self.squirrelflowdb.get_rule(archstring, bytestring)
        rule = acorn.TaintRule.deserialize(rule_string)
        return rule

    def check_rules(self, archstring, insn_list):
        missing_rules = self.squirrelflowdb.check_rules(archstring, insn_list)
        return missing_rules

    def train_rules(self, archstring, insn_list):
        return self.squirrelflowdb.train_rules(archstring, insn_list)

    def get_working(self):
        working = self.squirrelflowdb.get_working()
        return working

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('archstring')
    parser.add_argument('bytestring')
    args = parser.parse_args()

    config = load_config('squirrelflow', 'squirrelflow.cfg')
    conn = config['squirrelflow']['conn']
    port = config['squirrelflow']['port']
    conn_str = 'http://{}:{}'.format(conn, port)
    print(conn_str)
    squirrelflow = SquirrelFlow(conn, port)
    archstring = args.archstring
    bytestring = args.bytestring
    insn_set = [bytestring]
    missing = squirrelflow.check_rules(archstring,insn_set)
    if missing:
        print('missing:{}'.format(missing))
        #not_working = squirrelflow.check_working(archstring, insn_set)
        #print('not_working:{}'.format(not_working))
        al, rl = squirrelflow.train_rules(archstring, missing)
        print('accept:{}'.format(al))
        print('reject:{}'.format(rl))
    else:
        rule = squirrelflow.get_rule(archstring, bytestring)
        print(rule)
    print('working:{}'.format(squirrelflow.get_working()))

if __name__ == "__main__":
    main()
