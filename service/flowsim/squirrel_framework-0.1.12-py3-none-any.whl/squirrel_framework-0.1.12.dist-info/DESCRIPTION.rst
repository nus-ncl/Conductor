# squirrel
SQUIRREL, a framework that is designed to improve usability and efficiency of binary analysis by facilitating the collection and management of binary knowledge.


