try:
    from xmlrpc.server import SimpleXMLRPCServer
    from xmlrpc.client import Binary
except Exception as e:
    from SimpleXMLRPCServer import SimpleXMLRPCServer
    from xmlrpclib import Binary

import inspect
import signal
import threading
import sys
import binascii

from collections import namedtuple

import idautils
import idaapi
import idc

import ida_ua

#import idapro_obj_pb2 as idaobj

class IDAPro(object):
    @staticmethod
    def parse_phrase(specflag1, specflag2):
        assert(specflag1 == 1)
        base = specflag2 & 7
        index = (specflag2 >> 3) & 7
        scale = (specflag2 >> 6) & 3
        return (base, index, scale)

    @staticmethod
    def convert_insn_t(insn):
        if not insn:
            return None
        insn_t = idaobj.insn_t()
        insn_t.cs = insn.cs
        insn_t.ip = insn.ip
        insn_t.ea = insn.ea
        insn_t.itype = insn.itype
        insn_t.size = insn.size
        insn_t.auxpref = insn.auxpref
        insn_t.segpref = ord(insn.segpref)
        insn_t.insnpref = ord(insn.insnpref)
        insn_t.flags = insn.flags
        for op in insn.ops:
            op_t = idaobj.op_t()
            op_t.n = op.n
            op_t.type = op.type
            op_t.offb = op.offb
            op_t.offo = op.offo
            op_t.flags = op.flags
            op_t.dtype = op.dtype
            op_t.phrase = op.phrase
            op_t.value = op.value
            op_t.addr = op.addr
            op_t.specval = op.specval
            op_t.specflag1 = op.specflag1
            op_t.specflag2 = op.specflag2
            op_t.specflag3 = op.specflag3
            op_t.specflag4 = op.specflag4
            insn_t.ops.append(op_t)
        return insn_t

    def __init__(self):
        self.register_idc()

    def register_idc(self):
        # register idc related functions
        # these typically have no complex return structures
        # so we can safely forward the calls
        idc_functions = [
            "AddSeg",
            "AutoMark",
            "EVAL_FAILURE",
            "FindBinary",
            "FindText",
            "GetDisasm",
            "GetDouble",
            "GetFloat",
            "GetLocalType",
            "GetProcessorName",
            "LoadFile",
            "MakeFunction",
            "MakeStr",
            "MakeVar",
            "SaveFile",
            "SegEnd",
            "SegStart",
            "SetPrcsr",
            "SetSegmentType",
            "SetType",
            "SizeOf",
            "add_auto_stkpnt",
            "add_bpt",
            "add_default_til",
            "add_enum",
            "add_enum_member",
            "add_func",
            "add_segm_ex",
            "add_struc",
            "add_struc_member",
            "append_func_tail",
            "apply_type",
            "atoa",
            "atol",
            "batch",
            "byte_value",
            "call_system",
            "can_exc_continue",
            "choose_func",
            "clear_trace",
            "create_array",
            "create_byte",
            "create_double",
            "create_dword",
            "create_float",
            "create_oword",
            "create_pack_real",
            "create_qword",
            "create_strlit",
            "create_struct",
            "create_tbyte",
            "create_word",
            "create_yword",
            "define_local_var",
            "del_array_element",
            "del_bpt",
            "del_enum_member",
            "del_hash_string",
            "del_items",
            "del_segm",
            "del_stkpnt",
            "del_struc",
            "del_struc_member",
            "delete_all_segments",
            "delete_array",
            "demangle_name",
            "enable_tracing",
            "eval_idc",
            "expand_struc",
            "fclose",
            "fgetc",
            "filelength",
            "find_binary",
            "find_code",
            "find_data",
            "find_defined",
            "find_func_end",
            "find_imm",
            "find_selector",
            "find_suspop",
            "find_text",
            "find_unknown",
            "first_func_chunk",
            "fopen",
            "force_bl_call",
            "force_bl_jump",
            "form",
            "fprintf",
            "fputc",
            "fseek",
            "ftell",
            "func_contains",
            "gen_file",
            "gen_flow_graph",
            "gen_simple_call_chart",
            "generate_disasm_line",
            "get_array_element",
            "get_array_id",
            "get_bmask_cmt",
            "get_bmask_name",
            "get_bpt_attr",
            "get_bpt_ea",
            "get_bpt_qty",
            "get_bytes",
            "get_color",
            "get_curline",
            "get_enum_member",
            "get_enum_member_cmt",
            "get_enum_member_name",
            "get_event_bpt_hea",
            "get_event_ea",
            "get_event_exc_code",
            "get_event_exc_ea",
            "get_event_exc_info",
            "get_event_exit_code",
            "get_event_id",
            "get_event_info",
            "get_event_module_base",
            "get_event_module_name",
            "get_event_module_size",
            "get_event_pid",
            "get_event_tid",
            "get_fchunk_attr",
            "get_fchunk_referer",
            "get_first_enum_member",
            "get_first_hash_key",
            "get_first_index",
            "get_first_member",
            "get_first_module",
            "get_first_seg",
            "get_fixup_target_dis",
            "get_fixup_target_flags",
            "get_fixup_target_off",
            "get_fixup_target_sel",
            "get_fixup_target_type",
            "get_frame_args_size",
            "get_frame_id",
            "get_frame_lvar_size",
            "get_frame_regs_size",
            "get_frame_size",
            "get_func_attr",
            "get_func_cmt",
            "get_func_flags",
            "get_func_name",
            "get_func_off_str",
            "get_hash_long",
            "get_hash_string",
            "get_idb_path",
            "get_inf_attr",
            "get_item_size",
            "get_last_enum_member",
            "get_last_hash_key",
            "get_last_index",
            "get_last_member",
            "get_local_tinfo",
            "get_member_cmt",
            "get_member_flag",
            "get_member_id",
            "get_member_name",
            "get_member_offset",
            "get_member_qty",
            "get_member_size",
            "get_member_strid",
            "get_min_spd_ea",
            "get_module_name",
            "get_module_size",
            "get_name",
            "get_name_ea_simple",
            "get_next_enum_member",
            "get_next_fchunk",
            "get_next_func",
            "get_next_hash_key",
            "get_next_index",
            "get_next_module",
            "get_next_offset",
            "get_next_seg",
            "get_numbered_type_name",
            "get_operand_type",
            "get_operand_value",
            "get_ordinal_qty",
            "get_prev_enum_member",
            "get_prev_fchunk",
            "get_prev_func",
            "get_prev_hash_key",
            "get_prev_index",
            "get_prev_offset",
            "get_reg_value",
            "get_segm_attr",
            "get_segm_by_sel",
            "get_segm_end",
            "get_segm_name",
            "get_segm_start",
            "get_sp_delta",
            "get_spd",
            "get_sreg",
            "get_str_type",
            "get_strlit_contents",
            "get_tinfo",
            "get_type",
            "get_xref_type",
            "guess_type",
            "hasName",
            "hasUserName",
            "has_value",
            "here",
            "idadir",
            "import_type",
            "isBin0",
            "isBin1",
            "isDec0",
            "isDec1",
            "isExtra",
            "isHex0",
            "isHex1",
            "isOct0",
            "isOct1",
            "isRef",
            "is_align",
            "is_byte",
            "is_char0",
            "is_char1",
            "is_code",
            "is_data",
            "is_defarg0",
            "is_defarg1",
            "is_double",
            "is_dword",
            "is_enum0",
            "is_enum1",
            "is_event_handled",
            "is_float",
            "is_flow",
            "is_head",
            "is_loaded",
            "is_manual0",
            "is_manual1",
            "is_mapped",
            "is_off0",
            "is_off1",
            "is_oword",
            "is_pack_real",
            "is_qword",
            "is_seg0",
            "is_seg1",
            "is_stkvar0",
            "is_stkvar1",
            "is_strlit",
            "is_stroff0",
            "is_stroff1",
            "is_struct",
            "is_tail",
            "is_tbyte",
            "is_union",
            "is_unknown",
            "is_word",
            "loadfile",
            "ltoa",
            "make_array",
            "move_segm",
            "next_func_chunk",
            "next_head",
            "op_offset_high16",
            "op_plain_offset",
            "op_stroff",
            "parse_decl",
            "parse_decls",
            "plan_and_wait",
            "prev_head",
            "print_decls",
            "print_insn_mnem",
            "print_operand",
            "process_config_line",
            "process_ui_action",
            "qsleep",
            "read_dbg_byte",
            "read_dbg_dword",
            "read_dbg_qword",
            "read_dbg_word",
            "read_selection_end",
            "read_selection_start",
            "readlong",
            "readshort",
            "readstr",
            "remove_fchunk",
            "rename_array",
            "resume_process",
            "rotate_byte",
            "rotate_dword",
            "rotate_left",
            "rotate_word",
            "save_database",
            "savefile",
            "sel2para",
            "selector_by_name",
            "send_dbg_command",
            "set_array_long",
            "set_array_params",
            "set_array_string",
            "set_bmask_cmt",
            "set_bmask_name",
            "set_bpt_attr",
            "set_bpt_cond",
            "set_color",
            "set_default_sreg_value",
            "set_fchunk_attr",
            "set_fixup",
            "set_flag",
            "set_frame_size",
            "set_func_attr",
            "set_func_cmt",
            "set_func_flags",
            "set_hash_long",
            "set_hash_string",
            "set_inf_attr",
            "set_local_type",
            "set_member_cmt",
            "set_member_name",
            "set_member_type",
            "set_name",
            "set_reg_value",
            "set_segm_addressing",
            "set_segm_alignment",
            "set_segm_attr",
            "set_segm_class",
            "set_segm_combination",
            "set_segm_name",
            "set_segm_type",
            "set_segment_bounds",
            "set_struc_idx",
            "set_tail_owner",
            "split_sreg_range",
            "strlen",
            "strstr",
            "substr",
            "to_ea",
            "toggle_bnot",
            "update_hidden_range",
            "validate_idb_names",
            "value_is_float",
            "value_is_func",
            "value_is_int64",
            "value_is_long",
            "value_is_pvoid",
            "value_is_string",
            "write_dbg_memory",
            "writelong",
            "writeshort",
            "writestr",
            "xtol",
        ]

        for func_name in idc_functions:
            method_name = 'idc_{}'.format(func_name)
            method = getattr(idc, func_name)
            func_str = '''def idcwrap(*args, **kwargs):
    retval = idc.{}(*args, **kwargs)
    if isinstance(retval, str):
        return Binary(retval)
    else:
        return retval
'''.format(func_name)
            exec(func_str)
            setattr(self, method_name, idcwrap)

    # new apis to access ida pro
    # we'll export the individual methods with our own object defs
    # using proto3
    def idautils_DecodeInstruction(self, ea):
        insn = idautils.DecodeInstruction(ea)
        if not insn:
            return insn
        insn_t = IDAPro.convert_insn_t(insn)
        return Binary(insn_t.SerializeToString())

    def idautils_CodeRefsTo(self, ea, flow):
        return idautils.CodeRefsTo(ea, flow)

    def idautils_CodeRefsFrom(self, ea, flow):
        return idautils.CodeRefsFrom(ea, flow)

    def idautils_DataRefsTo(self, ea):
        return idautils.DataRefsTo(ea)

    def idautils_DataRefsFrom(self, ea):
        return idautils.DataRefsFrom(ea)

    def idautils_XrefTypeName(self, typecode):
        return idautils.XrefTypeName(typecode)

    def idautils_XrefsFrom(self, ea, flags):
        return idautils.XrefsFrom(ea, flags)

    def idautils_XrefsTo(self, ea, flags):
        return idautils.XrefsTo(ea, flags)

    def idautils_Heads(self, start=None, end=None):
        return idautils.Heads(start, end)

    def idautils_Functions(self, start=None, end=None):
        return idautils.Functions(start, end)

    def idautils_Chunks(self, start):
        return idautils.Chunks(start)

    def idautils_Names(self):
        return idautils.Names()

    def idautils_Segments(self):
        return idautils.Segments()

    def idautils_Entries(self):
        return idautils.Entries()

    def idautils_FuncItems(self, start):
        return idautils.FuncItems(start)

    def idautils_Structs(self):
        return idautils.Structs()

    def idautils_StructMembers(self, sid):
        return idautils.StructMembers(sid)

    def idautils_DecodePrecedingInstruction(self, ea):
        insn, farref = idautils.DecodeInstruction(ea)
        if not insn:
            return (insn, farref)
        insn_t = IDAPro.convert_insn_t(insn)
        return (Binary(insn_t.SerializeToString()), farref)

    def idautils_DecodePreviousInstruction(self, ea):
        insn = idautils.DecodePreviousInstruction(ea)
        if not insn:
            return insn
        insn_t = IDAPro.convert_insn_t(insn)
        return Binary(insn_t.SerializeToString())

    def idautils_MapDataList(self, ea, length, func, wordsize=1):
        return idautils.MapDataList(ea, length, func, wordsize)

    def idautils_GetInputFileMD5():
        return idautils.GetInputFileMD5()

    def idautils_GetIdbDir():
        return idautils.GetIdbDir()

    def idautils_Assemble(self, ea, line):
        return idautils.Assemble(ea, line)

    def idautils_ProcessUiActions(actions, flags=0):
        return idautils.ProcessUiActions(actions, flags)

    # END of idautils


    def ea2fn(self, ea):
        """
        Given an ea, find which function it belongs to.
        Returns the function's start address
        """
        return idc.get_func_attr(ea, idc.FUNCATTR_START)

    def get_functions(self):
        """
        Returns list(function addresses) in .text
        """
        fns = {}
        fn_addrs = idautils.Functions()
        for fn_addr in fn_addrs:
            # if fn_addr is not in .text, skip it
            fn_seg = idc.get_segm_name(fn_addr)
            fn_name = idc.get_func_name(fn_addr)
            if fn_seg not in fns:
                fns[fn_seg] = []
            fns[fn_seg].append((fn_name, fn_addr))
        return fns

    def get_basicblocks(self, fn_ea):
        bbs = []
        ida_fn = idaapi.get_func(fn_ea)
        flowchart = idaapi.FlowChart(ida_fn)
        for block in flowchart:
            start_ea = block.startEA
            end_ea = block.endEA
            bbs.append((start_ea, end_ea))
        return bbs

    def get_instructions(self):
        insns = []
        for head_ea in idautils.Heads():
            flags = idc.get_full_flags(head_ea)
            if idc.is_code(flags):
                insns.append(head_ea)
        return insns

    def get_disassembly(self, ea):
        return idc.GetDisasm(ea)

    def get_num_operands(self, ea):
        insn = idautils.DecodeInstruction(ea)


    def get_insn_bytestring(self, ea):
        insn = ida_ua.insn_t()
        insn_size = ida_ua.decode_insn(insn, ea)
        if not insn:
            return None
        insn_bytes = bytes(idaapi.get_many_bytes(ea, insn_size))
        insn_bytestring = binascii.hexlify(insn_bytes)
        return insn_bytestring

    def get_insnflows_x86(self, insn_ea):
        """
        For each instruction, get its normal flow and its branch flow. 
        Returns triple(normal_flow, [branch_flows], [indirect_flows])
        """
        MemRef = namedtuple('MemRef', ['ea', 'base', 'index', 
            'scale', 'displ'])
        normal_flow = None
        branch_flows = []
        # indirect flow is a vector representing (ea, base, index, scale, displ)
        indirect_flow = [None, None, None, None, None]
        insn = idautils.DecodeInstruction(insn_ea)
        # ZL: Check if the instruction is an indirect jump
        features = insn.get_canon_feature()
        is_indirect = bool(features & idaapi.CF_JUMP)
        xref = idaapi.xrefblk_t()
        flag = xref.first_from(insn_ea, idaapi.XREF_ALL)
        while flag:
            if xref.iscode:
                #check if really code
                if idc.is_code(idc.get_full_flags(xref.to)):
                    if xref.type == idaapi.fl_F:
                        # this is a normal flow, we're going to add it as a normal edge in the CFG
                        # print('normal flow from 0x%x to 0x%x' % (xref.frm,xref.to))
                        normal_flow = xref.to
                    elif xref.type == idaapi.fl_CF or xref.type == idaapi.fl_CN:
                        #we do not make a distinction between external calls or not
                        #print('branch flow from 0x%x to 0x%x'%(xref.frm,xref.to))
                        assert(xref.frm == insn_ea)
                        branch_flows.append(xref.to)
                    elif xref.type == idaapi.fl_JF or xref.type == idaapi.fl_JN:
                        #print('branch flow2 from 0x%x to 0x%x'%(xref.frm,xref.to))
                        #we do not make a distinction between external calls or not
                        assert(xref.frm == insn_ea)
                        branch_flows.append(xref.to)
            elif is_indirect:
                # ZL: caller is code, callee isn't code, caller is indirect
                indirect_flow[0] = xref.to
            flag = xref.next_from()
        if is_indirect and not indirect_flow:
            # ZL: its indirect but there is no memory address, it uses a register
            assert(insn.ops[1].type == 0)
            # ida_ua.void == 0
            #print('{} : {}'.format(hex(insn.ea), idc.GetDisasm(insn.ea)))
            #print('phrase: {}  reg: {} specflag1: {} specflag2: {}'.format(insn.ops[0].phrase, insn.ops[0].reg, insn.ops[0].specflag1, insn.ops[0].specflag2))
            reg_size = self.dtype2size(insn.ops[0].dtype)
            if insn.ops[0].type == 1:
                # ida_ua.o_reg == 1
                indirect_flow = idaapi.get_reg_name(insn.ops[0].reg, reg_size)
            elif insn.ops[0].type == 3 or insn.ops[0].type == 4:
                # ida_ua.o_phrase == 3, ida_ua.o_displ == 4
                # memory ref : 3 -- [base + index*scale] 
                #              4 -- [base + index*scale + displ]
                # specflag1
                if insn.ops[0].specflag1:
                    base,index,scale = IDAPro.parse_phrase(insn.ops[0].specflag1, insn.ops[0].specflag2)
                    base_reg = idaapi.get_reg_name(base, reg_size)
                    index_reg = idaapi.get_reg_name(index, reg_size)
                    indirect_flow[1] = base_reg
                    indirect_flow[2] = index_reg
                    indirect_flow[3] = 2 << scale
                else:
                    indirect_flow[1] = idaapi.get_reg_name(base, reg_size)
                if insn.ops[0].type == 4:
                    indirect_flow[4] = insn.ops[0].addr
            #print('{}'.format(indirect_flow))
        return (normal_flow, branch_flows, indirect_flow)

    def idc(self, method, args):
        method = getattr(idc, method)
        return method(*args)


class IDAProDaemon(SimpleXMLRPCServer):
    def __init__(self, *args, **kwargs):
        SimpleXMLRPCServer.__init__(self, *args, **kwargs)
    def remote_shutdown(self):
        threading.Thread(target=self.shutdown, args=()).start()

def main():
    # prep according to script or gui mode
    is_gui = True
    host = '0.0.0.0'
    if len(idc.ARGV) != 0:
        # take back stdout, stderr
        sys.stdout = _orig_stdout
        sys.stderr = _orig_stderr

        is_gui = False
        port = int(idc.ARGV[1])
        status_path = idc.ARGV[2]
    else:
        port = 37519

    # initialize the server
    server = IDAProDaemon((host, port), allow_none=True)
    server.register_function(server.remote_shutdown)
    server.register_introspection_functions()
    server.register_instance(IDAPro())

    # ZL: temp code to register idc members using introspection
    #for name, obj in inspect.getmembers(idc):
    #    if inspect.isfunction(obj) and name[0] != '_':
    #        print('Registering {}'.format(name))
    #        server.register_function(obj)

    # wait for analysis to be complete
    idaapi.auto_wait()
    print('Serving IDAPro on {}:{}'.format(host, port))
    if not is_gui:
        with open(status_path, 'w') as f:
            f.write('READY')
    server.serve_forever()
    print('{}\t: Shutting Down!'.format(port))
    server.server_close()
    if not is_gui:
        idc.qexit(0)

if __name__ == '__main__':
    main()
