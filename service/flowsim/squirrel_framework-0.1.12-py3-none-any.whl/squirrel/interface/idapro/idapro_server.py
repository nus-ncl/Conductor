import os
import shutil
import tempfile
import pkg_resources
import subprocess
import threading
import time
import signal
import random

from xmlrpc.server import SimpleXMLRPCServer
from xmlrpc.client import Binary

from squirrel.squirrel import load_config

_CONF_NAME = 'idapro_server'
_IDAPRO = 'squirrel.interface.idapro'

class IDAProServerCore(object):
    def __init__(self, config):
        pool_begin = int(config[_CONF_NAME]['pool_begin'])
        pool_size  = int(config[_CONF_NAME]['pool_size'])
        ida_dir = config[_CONF_NAME]['idapro_dir']
        self.ida64_path = os.path.join(ida_dir, 'idat64')
        self.daemon_script = pkg_resources.resource_filename(
                _IDAPRO, 'idapro_daemon.py')
        self._init_ports(pool_begin, pool_size)
        self._poll_thread_flag = True
        self._poll_thread = threading.Thread(target=self._poll_daemons, args=())
        self._poll_thread.start()

    def _init_ports(self, pool_begin, pool_size):
        self.available_ports = list(range(pool_begin, pool_begin+pool_size))
        self.taken_ports = []
        self.ida_threads = {}
        for port in self.available_ports:
            self.ida_threads[port] = None

    def _acquire_port(self):
        port = random.choice(self.available_ports)
        self.available_ports.remove(port)
        return port

    def _release_port(self, port):
        self.taken_ports.remove(port)
        self.available_ports.append(port)

    def check(self):
        return self.taken_ports, self.available_ports

    def _poll_daemons(self, poll_time=5):
        while self._poll_thread_flag:
            for port in self.taken_ports:
                ida_proc, tempdir, binary_name = self.ida_threads[port]
                ret_code = ida_proc.poll()
                if ret_code != None:
                    # server is no longer running, we'll clean up the metainfo
                    shutil.rmtree(tempdir)
                    self.ida_threads[port] = None
                    self._release_port(port)
            time.sleep(poll_time)
        # we're terminating the server, cleanup all remaining processes
        # and temp dirs
        for port in self.taken_ports:
            ida_proc, tempdir, binary_name = self.ida_threads[port]
            ida_proc.kill()
            shutil.rmtree(tempdir)

    def _get_user(self, api_key):
        return self.users[api_key]

    def list_daemons(self):
        active_daemons = {}
        for port in self.taken_ports:
            ida_proc, tempdir, binary_name = self.ida_threads[port]
            status_path = os.path.join(tempdir, 'status')
            with open(status_path, 'r') as f:
                status = f.read()
            active_daemons[str(port)] = (status, binary_name, ' '.join(ida_proc.args))
        return active_daemons

    def check_status(self, port):
        if isinstance(port, str):
            port = int(port)
        status = None
        if port in self.ida_threads:
            ida_proc, tempdir, binary_name = self.ida_threads[port]
            status_path = os.path.join(tempdir, 'status')
            with open(status_path, 'r') as f:
                status = f.read()
        return status

    def start_daemon(self, binary, binary_name='', api_key=''):
        if isinstance(binary, Binary):
            binary = binary.data
        assert(isinstance(binary, bytes))
        daemon_port = self._acquire_port()
        tempdir = tempfile.mkdtemp()
        _, tempfile_path = tempfile.mkstemp(dir=tempdir)
        with open(tempfile_path, 'wb') as f:
            f.write(binary)
        status_path = os.path.join(tempdir, 'status')
        with open(status_path, 'w') as f:
            f.write('LOADING')
        cmd = [self.ida64_path, '-c', '-A', '-S{} {} {}'.format(self.daemon_script,
            daemon_port, status_path), tempfile_path]
        ida_proc = subprocess.Popen(cmd)
        self.ida_threads[daemon_port] = (ida_proc, tempdir, binary_name)
        self.taken_ports.append(daemon_port)
        print('Starting daemon on port {} for user {}.'.format(daemon_port,
            api_key))
        return daemon_port

    def clean_shutdown(self):
        print('CTRL+C detected! Clean Shutdown!')
        self._poll_thread_flag = False
        print('Waiting for poll thread to join.')

class IDAProServer(SimpleXMLRPCServer):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        signal.signal(signal.SIGINT, self._handler)

    def _handler(self,x,y):
        self.instance.clean_shutdown()
        threading.Thread(target=self.shutdown, args=()).start()



def main():
    config = load_config(_IDAPRO, 'idapro_server.cfg')
    hostname = config[_CONF_NAME]['bind_hostname']
    port = int(config[_CONF_NAME]['bind_port'])
    print('Listning on {}:{}'.format(hostname, port))
    server = IDAProServer((hostname, port), allow_none=True)
    server.register_introspection_functions()
    ida_server = IDAProServerCore(config)
    server.register_instance(ida_server)
    server.serve_forever()
    server.server_close()

if __name__ == "__main__":
    main()
