import time

from xmlrpc.client import ServerProxy

import squirrel.acorn.acorn as acorn
import squirrel.interface.idapro.idapro_obj_pb2 as idapro_obj

class Stub(object):
    pass

class IDAProClient(object):
    def __init__(self, hostname, port):
        self.hostname = hostname
        conn_str = 'http://{}:{}'.format(hostname, port)
        self.idapro_server = ServerProxy(conn_str)

        self.idautils = Stub()
        self.idc = Stub()


    def workon_binary(self, binary_path):
        NUM_TRIES = 10
        WAIT_INTERVAL = 5

        with open(binary_path, 'rb') as f:
            binary = f.read()
        daemon_port = self.idapro_server.start_daemon(binary, binary_path)
        if not (daemon_port):
            print('Unable to get a daemon port!')
            return
        for x in range(NUM_TRIES):
            status = self.idapro_server.check_status(daemon_port)
            if status == 'READY':
                self.connect_daemon(self.hostname, daemon_port)
                return True
            time.sleep(WAIT_INTERVAL)
        conn_str = 'http://{}:{}'.format(self.hostname, daemon_port)
        print('{} is not ready. Please try again later.'.format(conn_str))
        self._cur_port = daemon_port
        return False

    def reconnect(self):
        if self.idapro_daemon:
            return 
        self.connect_daemon(self.hostname, self._cur_port)

    def getacorn_all_insns(self):
        if not self.idapro_daemon:
            return
        daemon = self.idapro_daemon
        potential_eas = daemon.get_instructions()
        return self.getacorn_insns(potential_eas)

    def getacorn_insns(self, eas):
        if not self.idapro_daemon:
            return
        for ea in eas:
            result.append(self.getacorn_insn(ea))

    def getacorn_insn(self, ea):
        if not self.idapro_daemon:
            return
        bytestring = daemon.get_insn_bytestring(ea)
        if not bytestring:
            return
        insn_t_data = daemon.idautils_DecodeInstruction(ea).data
        insn_t.ParseFromString(insn_t_data)

        insn_acorn = acorn.Instruction()
        insn_acorn.ea = ea
        insn_acorn.bytestring = bytestring
        insn_acorn.asm_string = daemon.get_disassembly(ea)
        return insn_acorn

    def connect_daemon(self, hostname, port):
        conn_str = 'http://{}:{}'.format(self.hostname, port)
        self.idapro_daemon = ServerProxy(conn_str)
        for name in self._get_methods():
            if name.startswith('idautils_'):
                remote_name = name[9:]
                setattr(self.idautils, remote_name, getattr(self.idapro_daemon, name))
            elif name.startswith('idc_'):
                remote_name = name[4:]
                setattr(self.idc, remote_name, getattr(self.idapro_daemon, name))
            else:
                setattr(self, name, getattr(self.idapro_daemon, name))

    def _get_methods(self):
        return self.idapro_daemon.system.listMethods()

    def shutdown(self):
        return self.idapro_daemon.shutdown()

def main():
    a = ServerProxy('http://192.168.11.100:37519', allow_none=True)
    #print(pickle.loads(a.test(0x402A16,True)))
    #print(a.system.listMethods())
    #print(a.print_insn_mnem(0x413c29))
    a.shutdown()

if __name__ == "__main__":
    main()
