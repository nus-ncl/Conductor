import json
import enum

class JSONAble(object):
    def jsonable(self):
        #dct = self.__dict__.copy()
        #for key, value in dct.items():
        #    if isinstance(value, enum.IntEnum):
        #        dct[key] = {'_obj_name':dct[key].__class__.__name__,
        #                'data':dct[key]}
        self.acorn_hash = self.hash()
        return {'_obj_name':self.__class__.__name__, 'data':self.__dict__}

    def serialize(self):
        from .serializer import SquirrelEncoder
        return json.dumps(self.jsonable(), cls=SquirrelEncoder)

    @staticmethod
    def deserialize(json_str):
        from .serializer import SquirrelDecoder
        obj = json.loads(json_str, cls=SquirrelDecoder)
        return obj

