import json

import squirrel.acorn.acorn as acorn

from .jsonable import JSONAble
from squirrel import Access


class SquirrelEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, set):
            return {'_obj_name':'set', 'data':list(obj)}
        elif isinstance(obj, int):
            return {'_obj_name':'int', 'data':str(obj)}
        elif isinstance(obj, Access):
            return {'_obj_name':'Access', 'data':obj}
        elif isinstance(obj, acorn.Flow.FlowType):
            return {'_obj_name':'FlowType', 'data':obj}
        elif isinstance(obj, acorn.Condition.CondOps):
            return {'_obj_name':'CondOps', 'data':obj}
        elif isinstance(obj, JSONAble):
            return obj.jsonable()
        else:
            return super().default(obj)

class SquirrelDecoder(json.JSONDecoder):
    def __init__(self, *args, **kwargs):
        json.JSONDecoder.__init__(self, object_hook=self.object_hook, *args, **kwargs)

    def object_hook(self, dct):
        if '_obj_name' not in dct:
            return dct
        obj_name = dct['_obj_name']
        if obj_name == 'set':
            obj = set(dct['data'])
        elif obj_name == 'int':
            obj = int(dct['data'])
        elif obj_name == 'Access':
            obj = Access(dct['data'])
        elif obj_name == 'FlowType':
            obj = acorn.Flow.FlowType(dct['data'])
        elif obj_name == 'CondOps':
            obj = acorn.Condition.CondOps(dct['data'])
        elif obj_name == 'TaintRule':
            obj = getattr(acorn, obj_name)()
            dataflows = []
            for d in dct['data']['dataflows']:
                dataflows.append({int(x):set([int(i) for i in y]) for x,y in d.items()})
            dct['data']['dataflows'] = dataflows
            obj.__dict__ = dct['data']
        elif hasattr(acorn, obj_name):
            obj = getattr(acorn, obj_name)()
            obj.__dict__ = dct['data']
        #elif hasattr(taintinduce_common, obj_name):
        #    obj = getattr(taintinduce_common, obj_name)()
        #    obj.__dict__ = dct['data']
        else:
            raise Exception("Unknown obj_name!")
        return obj
