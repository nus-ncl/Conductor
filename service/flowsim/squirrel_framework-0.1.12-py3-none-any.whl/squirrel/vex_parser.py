#!/usr/bin/env python3

import pyvex
import archinfo
import operator
import binascii

import sys
import networkx as nx

from enum import Enum
from collections import defaultdict

import pdb

def get_tmp_name(tmp_val):
    tmp_name = 'tmp_{}'.format(tmp_val)
    return tmp_name

## Custom Operators
def nop(expr):
    return expr

def cmp_eq(arg1, arg2):
    return arg1 == arg2

## Local naming

current_reg_id = defaultdict(int)
operator_idx = 0
mem_idx = [1,1]
# TODO: probably need to fold the insn_reg nonsense into arch
arch = archinfo.ArchAMD64()
insn_reg = 'RIP'
cond_reg = "EFLAGS"

irsb = None

def init_insn():
    global current_reg_id
    global operator_idx
    global mem_idx
    global arch
    current_reg_id = defaultdict(int)
    operator_idx = 0
    mem_idx = [1,1]

def read_reg(reg):
    global current_reg_id
    # TODO: HACK for hackathon! have to integrate cleanly
    if reg == 'D':
        reg = cond_reg

    reg_name = '{}_{}'.format(reg, current_reg_id[reg])
    return reg_name

def write_reg(reg):
    global current_reg_id
    current_reg_id[reg] += 1
    reg_name = '{}_{}'.format(reg, current_reg_id[reg])
    return reg_name

def write_mem(size):
    global mem_idx
    mem_name = 'MEM_WRITE_{}'.format(mem_idx[1])
    mem_idx[1] += 1
    return ('{}_VALUE_{}_Z'.format(mem_name, size), '{}_ADDR_{}_Z'.format(mem_name, size))

def read_mem(size):
    global mem_idx
    mem_name = 'MEM_READ_{}'.format(mem_idx[0])
    mem_idx[0] += 1
    return ('{}_VALUE_{}_Z'.format(mem_name, size), '{}_ADDR_{}_Z'.format(mem_name, size))

def get_op(op_name):
    global operator_idx
    uniq_op_name = '{}_{}'.format(op_name, operator_idx)
    operator_idx += 1
    return uniq_op_name

## AMD64 Conditions

class AMD64CondCode(Enum):
    AMD64CondO      = 0   # overflow           
    AMD64CondNO     = 1   # no overflow        
    AMD64CondB      = 2   # below              
    AMD64CondNB     = 3   # not below          
    AMD64CondZ      = 4   # zero               
    AMD64CondNZ     = 5   # not zero           
    AMD64CondBE     = 6   # below or equal     
    AMD64CondNBE    = 7   # not below or equal 
    AMD64CondS      = 8   # negative           
    AMD64CondNS     = 9   # not negative       
    AMD64CondP      = 10  # parity even        
    AMD64CondNP     = 11  # not parity even    
    AMD64CondL      = 12  # jump less          
    AMD64CondNL     = 13  # not less           
    AMD64CondLE     = 14  # less or equal      
    AMD64CondNLE    = 15  # not less or equal  
    AMD64CondAlways = 16  # HACK 

class X86CondCode(Enum):
    X86CondO      = 0   # overflow           
    X86CondNO     = 1   # no overflow        
    X86CondB      = 2   # below              
    X86CondNB     = 3   # not below          
    X86CondZ      = 4   # zero               
    X86CondNZ     = 5   # not zero           
    X86CondBE     = 6   # below or equal     
    X86CondNBE    = 7   # not below or equal 
    X86CondS      = 8   # negative           
    X86CondNS     = 9   # not negative       
    X86CondP      = 10  # parity even        
    X86CondNP     = 11  # not parity even    
    X86CondL      = 12  # jump less          
    X86CondNL     = 13  # not less           
    X86CondLE     = 14  # less or equal      
    X86CondNLE    = 15  # not less or equal  
    X86CondAlways = 16  # HACK 

class ARMCondCode(Enum):
    ARMCondEQ = 0 # equal
    ARMCondNE = 1 # not equal
    ARMCondHS = 2 # carry set, or unsigned higher or same
    ARMCondLO = 3 # carry clear or unsigned lower
    ARMCondMI = 4 # negative
    ARMCondPL = 5 # positive or zero
    ARMCondVS = 6 # overflow
    ARMCondVC = 7 # no overflow
    ARMCondHI = 8 # unsigned higher
    ARMCondLS = 9 # unsigned lower or same
    ARMCondGE = 10 # signed greater than or equal
    ARMCondLT = 11 # signed less than
    ARMCondGT = 12 # signed greater than
    ARMCondLE = 13 # signed less than or equal
    ARMCondAL = 14 # always 

## Parsing interfaces

def parse_expr(expr, mygraph):
    if expr == None:
        return
    if type(expr) not in expr_types:
        pdb.set_trace()
    return expr_types[type(expr)](expr, mygraph)

def parse_stmt(stmt, mygraph):
    if type(stmt) not in stmt_types:
        pdb.set_trace()
    #print(type(stmt))
    #print(stmt)
    return stmt_types[type(stmt)](stmt, mygraph)

def set_arch(archh):
    global arch
    global insn_reg
    global cond_reg
    # TODO: probably need to fold the insn_reg thing into arch
    #print(archh)
    if archh == 'AMD64':
        arch = archinfo.ArchAMD64()
        insn_reg = 'rip'
        cond_reg = "EFLAGS"
    elif archh == 'AARCH32':
        arch = archinfo.ArchARM()
        insn_reg = 'pc'
        cond_reg = "CPSR"
    elif archh == 'X86':
        arch = archinfo.ArchX86()
        insn_reg = 'eip'
        cond_reg = "EFLAGS"
    elif archh == 'AARCH64':
        arch = archinfo.ArchAArch64()
        insn_reg = 'pc'
        cond_reg = "CPSR"
    else:
        raise Exception('Arch not supported!')


def parse_rawbytes(rawbytes, addr, debug=False):
    global irsb
    init_insn()
    asg = nx.DiGraph()
    irsb = pyvex.lift(rawbytes, addr, arch)
    if debug:
        print(irsb)
    for stmt in irsb.statements:
        parse_stmt(stmt, asg)
    # parse next
    dest = write_reg(insn_reg)
    src = parse_expr(irsb.next, asg)
    asg.add_edge(src, dest)
    return asg

## Vex statements

def _parseMBE(stmt, _):
    # Memory fence instruction...
    pass

def _parseIMark(stmt, _):
    # IMark marks the start of a machine instruction
    pass

def _parseDirty(stmt, mygraph):
    if stmt.cee.name == 'amd64g_dirtyhelper_loadF80le':
        dst = get_tmp_name(stmt.tmp)
        if type(stmt.args[0]) == pyvex.expr.RdTmp:
            val = _parseRdTmp(stmt.args[0], mygraph)
        else:
            val = _parseConst(stmt.args[0], mygraph)
        mygraph.add_node(dst)
        mygraph.add_edge(val, dst) 
        return dst
    
    #TODO: figure out shit.
    # t4294967295 = DIRTY 1 TODO(effects) ::: amd64g_dirtyhelper_storeF80le(t0,t1) 
    cee = _parseCCall(stmt, mygraph)
    mygraph.add_node(cee)
    for arg in stmt.args:
        if type(arg) == pyvex.expr.RdTmp:
            arg_var = get_tmp_name(arg)
            mygraph.add_node(arg_var)
            mygraph.add_edge(arg_var, cee)
        elif type(arg) == pyvex.expr.Const:
            const_var = _parseConst(arg, mygraph)
            mygraph.add_edge(const_var, cee)
        elif type(arg) == pyvex.expr.GSPTR:
            #TODO: Figure this out!!!! IMPT!!! 
            pass
        else:
            pdb.set_trace()
            raise Exception
    written_var = get_tmp_name(stmt.tmp)
    mygraph.add_node(written_var)
    mygraph.add_edge(written_var, cee)
    return cee 


def _parsePut(stmt, mygraph):
    global irsb
    size = stmt.data.result_size(irsb.tyenv) // 8
    reg_write = write_reg(arch.translate_register_name(stmt.offset, size))
    try:
        arch.get_register_offset(reg_write)
    except:
        return None
    stmt_offset = reg_write
    stmt_expr = parse_expr(stmt.data, mygraph)
    mygraph.add_edge(stmt_expr, stmt_offset)
    return stmt_offset

def _parsePutI(stmt, mygraph):
    #TODO: double check correctness 
    array_written = write_reg(arch.translate_register_name(stmt.descr.base))
    array_var = parse_expr(stmt.ix, mygraph)
    var_offset = 'IMM_{}'.format(stmt.bias)
    value_to_write = parse_expr(stmt.data, mygraph)

    mygraph.add_node(array_written)
    mygraph.add_node(var_offset)
    mygraph.add_edge(array_var, array_written)
    mygraph.add_edge(var_offset, array_written)
    mygraph.add_edge(value_to_write, array_written)
    return array_written

def _parseWrTmp(stmt, mygraph):
    # WrTmp writes to a temporary variable
    tmp_var =  get_tmp_name(stmt.tmp)
    expr = stmt.data
    expr_node = parse_expr(expr, mygraph)
    mygraph.add_edge(expr_node, tmp_var)
    return tmp_var

def _parseStore(stmt, mygraph):
    global irsb
    mem_addr = parse_expr(stmt.addr, mygraph)
    value = parse_expr(stmt.data, mygraph)
    mem_size = stmt.data.result_size(irsb.tyenv) // 8
    m, m_addr = write_mem(mem_size)
    mygraph.add_edge(mem_addr, m_addr)
    mygraph.add_edge(value, m)
    return m

def _parseExit(stmt, mygraph):
    guard = parse_expr(stmt.guard, mygraph)
    myguardop = get_op('IF')
    op = get_op("JUMP")

    mygraph.add_edge(guard, myguardop)
    mygraph.add_edge(myguardop, op)
    return op

def _parseLoadG(stmt, mygraph):
    dst = get_tmp_name(stmt.dst)  #t3
    mem_addr = parse_expr(stmt.addr, mygraph) #t10
    mem_size = pyvex.const.get_type_size(stmt.cvt_types[1]) // 8
    # mem_addr_alt is not a mem_addr, its the alternate expr to be loaded
    mem_addr_alt = parse_expr(stmt.alt, mygraph) #t12
    m, m_addr = read_mem(mem_size)

    mygraph.add_edge(mem_addr_alt, dst)
    mygraph.add_edge(m, dst)
    mygraph.add_edge(mem_addr, m_addr)

def _parseAbiHint(stmt, mygraph):
    return None

def _parseCAS(stmt, mygraph):
    expected_lo = parse_expr(stmt.expdLo, mygraph)
    expected_hi = parse_expr(stmt.expdHi, mygraph)
    data_lo = parse_expr(stmt.dataLo, mygraph)
    data_hi = parse_expr(stmt.dataHi, mygraph)
    mem_dst = parse_expr(stmt.addr, mygraph)

    old_lo = get_tmp_name(stmt.oldLo)
    old_hi = get_tmp_name(stmt.oldHi)
    size = stmt.expdLo.result_size(irsb.tyenv) // 8
    mem_val, mem_addr = write_mem(size)
    mem_rval, mem_raddr = read_mem(size)

    mygraph.add_edge(mem_dst, mem_addr)
    mygraph.add_edge(mem_dst, mem_raddr)
    mygraph.add_edge(data_lo, mem_val)
    mygraph.add_edge(data_hi, mem_val)
    mygraph.add_edge(mem_rval, old_lo)
    mygraph.add_edge(mem_rval, old_hi)

## Vex Expr

def _parseITE(expr, mygraph):
    true_expr = parse_expr(expr.iftrue, mygraph)
    false_expr = parse_expr(expr.iffalse, mygraph)
    cond_expr = parse_expr(expr.cond, mygraph)
    mygraph.add_edge(cond_expr, 'ITE', ite_type='cond')
    mygraph.add_edge(true_expr, 'ITE', ite_type='true')
    mygraph.add_edge(false_expr, 'ITE', ite_type='false')
    return 'ITE'


def _parseConst(expr, mygraph):
    constant_value = expr.con.value
    mynode = get_op('IMM_{}'.format(constant_value))
    mygraph.add_node(mynode)
    return mynode

def _parseGet(expr, mygraph):
    # this expression reads a guest register at a fixed offset of the guest state
    expr_ty = expr.ty
    expr_size = pyvex.get_type_size(expr_ty) // 8
    reg_read = read_reg(arch.translate_register_name(expr.offset, expr_size))
    try:
        arch.get_register_offset(reg_read)
    except:
        return None
    mygraph.add_node(reg_read)
    return reg_read

def _parseGetI(expr, mygraph):
    #TODO: figure out if this parsing is correct
    # Read a guest register at a non-fixed offset in the guest state.
    arr_base = read_reg(arch.translate_register_name(expr.descr.base))
    ix = parse_expr(expr.ix, mygraph)
    offset_from_ix = 'IMM_{}'.format(expr.bias)
    mygraph.add_node(arr_base)
    mygraph.add_node(offset_from_ix)
    mygraph.add_edge(ix, arr_base)
    mygraph.add_edge(offset_from_ix, arr_base)
    return arr_base

def _parseLoad(expr, mygraph):
    global irsb
    mem_addr = parse_expr(expr.addr, mygraph)
    mem_size = expr.result_size(irsb.tyenv) // 8
    m, m_addr = read_mem(mem_size)

    mygraph.add_edge(mem_addr, m_addr)
    mygraph.add_node(m)
    return m

def _parseBinop(expr, mygraph):
    #print(expr)
    # TODO: hack hack hack if op not found, we just represent it as a string
    if expr.op not in binop_types:
        binop_types[expr.op] = str(expr.op)
    myop = get_op(binop_types[expr.op])
    mygraph.add_node(myop)
    for sub_expr in expr.args:
        new_node = parse_expr(sub_expr, mygraph)
        mygraph.add_edge(new_node, myop)
    return myop

def _parseTriop(expr, mygraph):
    if expr.op not in triop_types:
        triop_types[expr.op] = str(expr.op)
    myop = get_op(triop_types[expr.op])
    mygraph.add_node(myop)
    for sub_expr in expr.args:
        new_node = parse_expr(sub_expr, mygraph)
        mygraph.add_edge(new_node, myop)
    return myop

def _parseUnop(expr, mygraph):
    if expr.op not in unop_types:
        unop_types[expr.op] = str(expr.op)
    myop = get_op(unop_types[expr.op])
    mygraph.add_node(myop)
    for sub_expr in expr.args:
        new_node = parse_expr(sub_expr, mygraph)
        mygraph.add_edge(new_node, myop)
    return myop

def _parseRdTmp(expr, mygraph):
    # reads value from temp variable
    tmp_var = get_tmp_name(expr.tmp)
    mygraph.add_node(tmp_var)
    return tmp_var

def _parseCCall(expr, mygraph):
    #TODO: Add node for conditional calculation
    return callee[expr.cee.name](expr, mygraph)

## Helper Functions
def armg_calculate_condition(expr, mygraph):
    #TODO: Compute semantics for helper function
    cond, cc_op, cc_dep1, cc_dep2 = expr.args
    arg0 = parse_expr(cond, mygraph)
    arg1 = parse_expr(cc_op, mygraph)
    arg2 = parse_expr(cc_dep1, mygraph)
    arg3 = parse_expr(cc_dep2, mygraph)
    # TODO: temp hack to get arch cond flags to work
    myop = get_op("CALCULATE_CONDITION")

    mygraph.add_edge(arg0, myop)
    mygraph.add_edge(arg1, myop)
    mygraph.add_edge(arg2, myop)
    mygraph.add_edge(arg3, myop)
    mygraph.add_edge('CPSR_Z', myop)
    return myop

def amd64g_check_fldcw(expr, mygraph):
    #TODO: checks fldcw only, do nothing since we 
    #don't care about checks?
    return None

def amd64g_calculate_RCR(expr, mygraph):
    # TODO:ZL: PLEASE IMPLEMENT!
    return None

def amd64g_dirtyhelper_storeF80le(expr, mygraph):
    #TODO:
    #raise Exception
    return expr.cee.name

def amd64g_create_fpucw(expr, mygraph):
    #TODO: VERIFY COrReCTNESS
    #raise Exception
    var = parse_expr(expr.args[0], mygraph)
    mygraph.add_node(var)
    return var

def x86g_calculate_condition(expr, mygraph):
    #TODO: Compute semantics for helper function
    cond, cc_op, cc_dep1, cc_dep2, cc_ndep = expr.args
    arg0 = X86CondCode(cond.con.value).name
    arg1 = parse_expr(cc_op, mygraph)
    arg2 = parse_expr(cc_dep1, mygraph)
    arg3 = parse_expr(cc_dep2, mygraph)
    arg4 = parse_expr(cc_ndep, mygraph)
    myop = get_op("CALCULATE_CONDITION")

    mygraph.add_edge(arg0, myop)
    mygraph.add_edge(arg1, myop)
    mygraph.add_edge(arg2, myop)
    mygraph.add_edge(arg3, myop)
    mygraph.add_edge(arg4, myop)
    mygraph.add_edge('EFLAGS_Z', myop)
    return myop

def x86g_calculate_eflags_c(expr, mygraph):
    cc_op, cc_dep1, cc_dep2, cc_ndep = expr.args
    arg0 = parse_expr(cc_op, mygraph)
    arg1 = parse_expr(cc_dep1, mygraph)
    arg2 = parse_expr(cc_dep2, mygraph)
    arg3 = parse_expr(cc_ndep, mygraph)
    myop = get_op("READ_RFLAGS")

    mygraph.add_edge(arg0, myop)
    mygraph.add_edge(arg1, myop)
    mygraph.add_edge(arg2, myop)
    mygraph.add_edge(arg3, myop)
    mygraph.add_edge('EFLAGS_Z', myop)
    return myop

def amd64g_calculate_condition(expr, mygraph):
    #TODO: Compute semantics for helper function
    cond, cc_op, cc_dep1, cc_dep2, cc_ndep = expr.args
    arg0 = AMD64CondCode(cond.con.value).name
    arg1 = parse_expr(cc_op, mygraph)
    arg2 = parse_expr(cc_dep1, mygraph)
    arg3 = parse_expr(cc_dep2, mygraph)
    arg4 = parse_expr(cc_ndep, mygraph)
    myop = get_op("CALCULATE_CONDITION")

    mygraph.add_edge(arg0, myop)
    mygraph.add_edge(arg1, myop)
    mygraph.add_edge(arg2, myop)
    mygraph.add_edge(arg3, myop)
    mygraph.add_edge(arg4, myop)
    mygraph.add_edge('RFLAGS_Z', myop)
    return myop

def amd64g_calculate_rflags_c(expr, mygraph):
    cc_op, cc_dep1, cc_dep2, cc_ndep = expr.args
    arg0 = parse_expr(cc_op, mygraph)
    arg1 = parse_expr(cc_dep1, mygraph)
    arg2 = parse_expr(cc_dep2, mygraph)
    arg3 = parse_expr(cc_ndep, mygraph)
    myop = get_op("READ_RFLAGS")

    mygraph.add_edge(arg0, myop)
    mygraph.add_edge(arg1, myop)
    mygraph.add_edge(arg2, myop)
    mygraph.add_edge(arg3, myop)
    mygraph.add_edge('RFLAGS_Z', myop)
    return myop


def armg_calculate_flag_c(expr, mygraph):
    cc_op, cc_dep1, cc_dep2, cc_ndep = expr.args
    arg0 = parse_expr(cc_op, mygraph)
    arg1 = parse_expr(cc_dep1, mygraph)
    arg2 = parse_expr(cc_dep2, mygraph)
    arg3 = parse_expr(cc_ndep, mygraph)
    myop = get_op("READ_FLAG")

    mygraph.add_edge(arg0, myop)
    mygraph.add_edge(arg1, myop)
    mygraph.add_edge(arg2, myop)
    mygraph.add_edge(arg3, myop)
    mygraph.add_edge('CPSR_Z', myop)
    return myop

def NOT_IMPLEMENTED(expr, mygraph):
    #pdb.set_trace()
    return 'NOTIMPLEMENTED_Z'


expr_types = {}
expr_types[pyvex.expr.Get] = _parseGet
expr_types[pyvex.expr.GetI] = _parseGetI
expr_types[pyvex.expr.Load] = _parseLoad
expr_types[pyvex.expr.RdTmp] = _parseRdTmp
expr_types[pyvex.expr.Const] = _parseConst
expr_types[pyvex.expr.Binop] = _parseBinop
expr_types[pyvex.expr.Triop] = _parseTriop
expr_types[pyvex.expr.Unop] = _parseUnop
expr_types[pyvex.expr.CCall] = _parseCCall
expr_types[pyvex.expr.ITE] = _parseITE

stmt_types = {}
stmt_types[pyvex.stmt.Dirty] = _parseDirty
stmt_types[pyvex.stmt.IMark] = _parseIMark
stmt_types[pyvex.stmt.WrTmp] = _parseWrTmp
stmt_types[pyvex.stmt.Put] = _parsePut
stmt_types[pyvex.stmt.PutI] = _parsePutI
stmt_types[pyvex.stmt.Store] = _parseStore
stmt_types[pyvex.stmt.StoreG] = _parseStore
stmt_types[pyvex.stmt.Exit] = _parseExit
stmt_types[pyvex.stmt.AbiHint] = _parseAbiHint
stmt_types[pyvex.stmt.LoadG] = _parseLoadG
stmt_types[pyvex.stmt.MBE] = _parseMBE
stmt_types[pyvex.stmt.CAS] = _parseCAS

## for now, we'll set all the operators as text

binop_types = {}
#binop_types['Iop_Add64'] = operator.add
#binop_types['Iop_Sub64'] = operator.sub
#binop_types['Iop_CmpEQ64'] = cmp_eq
#binop_types['Iop_CmpEQ8'] = cmp_eq
binop_types['Iop_Add64'] = "ADD"
binop_types['Iop_Add64F0x2'] = "ADD"
binop_types['Iop_Add64x2'] = "ADD"
binop_types['Iop_Sub64'] = "SUB"
binop_types['Iop_Sub32F0x4'] = "SUB"
binop_types['Iop_CmpF64'] = "CMP" 
binop_types['Iop_CmpEQ64'] = "EQUAL"
binop_types['Iop_CmpEQ32'] = "EQUAL"
binop_types['Iop_CmpEQ8'] = "EQUAL"
binop_types['Iop_Shl64'] = "SHL64"
binop_types['Iop_Shl32'] = "SHL32"
binop_types['Iop_ShlN64x2'] = "SHL64"
binop_types['Iop_64HLto128'] = "JOIN"
binop_types['Iop_32HLto64'] = "JOIN"
binop_types['Iop_DivModU128to64'] = "DIV"
binop_types['Iop_Div64F0x2'] = "DIV"
binop_types['Iop_DivModU64to32'] = "DIV"
binop_types['Iop_Div32F0x4'] = "DIV"
binop_types['Iop_DivModS64to32'] = "DIV"
binop_types['Iop_Mul32'] = "MUL"
binop_types['Iop_Mul64'] = "MUL"
binop_types['Iop_MullU32'] = "MUL"
binop_types['Iop_MullU64'] = "MUL"
binop_types['Iop_MullS32'] = "MUL"
binop_types['Iop_Mul32F0x4'] = "MUL"
binop_types['Iop_MullS8'] = "MUL"
binop_types['Iop_MullS64'] = "MUL"
binop_types['Iop_Mul64F0x2'] = "MUL"
binop_types['Iop_And64'] = "AND"
binop_types['Iop_CmpNE8'] = "NEQUAL"
binop_types['Iop_CmpNE64'] = "NEQUAL"
binop_types['Iop_CmpNE32'] = "NEQUAL"
binop_types['Iop_Xor64'] = "XOR"
binop_types['Iop_And32'] = "AND"
binop_types['Iop_Shr64'] = "SHR"
binop_types['Iop_Shr32'] = "SHR"
binop_types['Iop_Sar64'] = "SAR"
binop_types['Iop_Sar32'] = "SAR"
binop_types['Iop_And8'] = "AND"
binop_types['Iop_And16'] = "AND"
binop_types['Iop_Add32'] = "ADD"
binop_types['Iop_Add16'] = "ADD"
binop_types['Iop_Add8'] = "ADD"
binop_types['Iop_Add32F0x4'] = "ADD"
binop_types['Iop_Sub32'] = "SUB"
binop_types['Iop_Sub8'] = "SUB"
binop_types['Iop_Xor32'] = "XOR"
binop_types['Iop_Xor8'] = "XOR"
binop_types['Iop_Or32'] = "OR"
binop_types['Iop_Or8'] = "OR"
binop_types['Iop_Or64'] = "OR"
binop_types['Iop_F64toI32U'] = "FLOATTOINT"
binop_types['Iop_F64toI64S'] = "FLOATTOINT"
binop_types['Iop_I64StoF64'] = 'INTTOFLOAT'
binop_types['Iop_CmpLT32U'] = "LESS"
binop_types['Iop_F64toF32'] = "SIGNCOMPRESS"
binop_types['Iop_InterleaveLO64x2'] = "INTERLEAVE"
binop_types['Iop_CmpEQ8x16'] = "Iop_CmpEQ8x16"
binop_types['Iop_ExpCmpNE64'] = "Iop_ExpCmpNE64"
binop_types['Iop_64HLtoV128'] = "Iop_64HLtoV128"
binop_types['Iop_Sub8x16'] = "Iop_Sub8x16"
binop_types['Iop_InterleaveLO8x16'] = "Iop_InterleaveLO8x16"
binop_types['Iop_InterleaveLO16x8'] = "Iop_InterleaveLO16x8"
binop_types['Iop_OrV128'] = "Iop_OrV128"

triop_types = {}
triop_types['Iop_DivF32'] = 'DivF32'
triop_types['Iop_AddF32'] = 'AddF32'
triop_types['Iop_MulF32'] = 'MulF32'
triop_types['Iop_MulF64'] = 'MulF64'
triop_types['Iop_DivF64'] = 'DivF64'
triop_types['Iop_AddF64'] = 'AddF64'
triop_types['Iop_SubF64'] = 'SubF64'

unop_types = {}
#unop_types['Iop_64to32'] = nop
#unop_types['Iop_32Uto64'] = nop
#unop_types['Iop_64to1'] = nop
#unop_types['Iop_8Uto64'] = nop
#unop_types['Iop_64to8'] = nop
#unop_types['Iop_1Uto64'] = nop
unop_types['Iop_64to32'] = '64to32'
unop_types['Iop_32Uto64'] = '32Uto64'
unop_types['Iop_64to1'] = '64to1'
unop_types['Iop_32to1'] = '32to1'
unop_types['Iop_32to16'] = '32to16'
unop_types['Iop_32to8'] = '32to8'
unop_types['Iop_8Uto64'] = '8Uto64'
unop_types['Iop_64to8'] = '64to8'
unop_types['Iop_1Uto64'] = '1Uto64'
unop_types['Iop_32Sto64'] = '32Sto64'
unop_types['Iop_128to64'] = '128to64'
unop_types['Iop_64HIto32'] = '64HIto32'
unop_types['Iop_128HIto64'] = '128HIto64'
unop_types['Iop_1Uto8'] = '1Uto8'
unop_types['Iop_8Uto32'] = '8Uto32'
unop_types['Iop_16Uto32'] = '16Uto32'
unop_types['Iop_16Uto64'] = '16Uto64'
unop_types['Iop_64to16'] = '64to16'
unop_types['Iop_Not32'] = 'Not32'
unop_types['Iop_Clz32'] = 'Clz32'
unop_types['Iop_ReinterpI64asF64'] = 'ReinterpI64asF64'
unop_types['Iop_F32toF64'] = 'F32toF64'
unop_types['Iop_ReinterpF32asI32'] = 'ReinterpF32asI32'
unop_types['Iop_I32StoF64'] = 'I32StoF64'
unop_types['Iop_Not1'] = 'Not1'
unop_types['Iop_ReinterpF64asI64'] = 'ReinterpF64asI64'
unop_types['Iop_16Sto32'] = '16Sto32'
unop_types['Iop_ReinterpI32asF32'] = 'ReinterpI32asF32'
unop_types['Iop_I32UtoF64'] = 'I32UtoF64'
unop_types['Iop_NegF64'] = 'NegF64'
unop_types['Iop_32UtoV128'] = '32UtoV128'
unop_types['Iop_8Sto32'] = '8Sto32'
unop_types['Iop_Not64'] = 'Not64'
unop_types['Iop_64UtoV128'] = '64UtoV128'
unop_types['Iop_8Sto64'] = '8Sto64'
unop_types['Iop_GetMSBs8x16'] = "Iop_GetMSBs8x16"
unop_types['Iop_Ctz64'] = "Iop_Ctz64"
unop_types['Iop_V128HIto64'] = "Iop_V128HIto64"
unop_types['Iop_V128to64'] = "Iop_V128to64"

callee = {}
callee['amd64g_calculate_RCR'] = amd64g_calculate_RCR
callee['amd64g_check_fldcw'] = amd64g_check_fldcw
callee['amd64g_create_fpucw'] = amd64g_create_fpucw
callee['amd64g_dirtyhelper_storeF80le'] = amd64g_dirtyhelper_storeF80le
callee['amd64g_calculate_condition'] = amd64g_calculate_condition
callee['x86g_calculate_condition'] = x86g_calculate_condition
callee['x86g_calculate_eflags_c'] = x86g_calculate_eflags_c
callee['x86g_calculate_eflags_all'] = x86g_calculate_eflags_c
callee['armg_calculate_condition'] = armg_calculate_condition
callee['amd64g_calculate_rflags_c'] = amd64g_calculate_rflags_c
callee['armg_calculate_flag_c'] = armg_calculate_flag_c
callee['armg_calculate_flag_v'] = armg_calculate_flag_c
callee['amd64g_calculate_rflags_all'] = amd64g_calculate_rflags_c
callee['amd64g_dirtyhelper_RDTSC'] = NOT_IMPLEMENTED
callee['amd64g_dirtyhelper_CPUID_avx2'] = NOT_IMPLEMENTED
