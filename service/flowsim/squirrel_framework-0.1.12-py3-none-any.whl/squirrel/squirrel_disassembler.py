import capstone

from . import pydis
from .pydis import types

import squirrel.acorn.acorn as acorn

from squirrel import check_type, Access
from .isa.registers import get_register_arch

class SquirrelDisassembler(object):
    def __init__(self):
        pass

    def disassemble(self, archstring, bytestring):
        raise NotImplementedError

class SquirrelDisassemblerZydis(object):
    def __init__(self, archstring):
        check_type(archstring, str)
        self.archstring = archstring
        if archstring == 'X86':
            self.machine_mode = pydis.MachineMode.LongCompat32
            self.address_width = 32
        elif archstring == 'AMD64':
            self.machine_mode = pydis.MachineMode.Long64
            self.address_width = 64
        else:
            raise Exception('Architecture not supported!')

    def disassemble(self, bytestring, ea=0x1000):
        ISARegister = get_register_arch(self.archstring)
        instruction = acorn.Instruction()
        rawbytes = bytes.fromhex(bytestring)
        zydis_insn_list = list(pydis.decode(rawbytes, ea, self.machine_mode, self.address_width))
        assert(len(zydis_insn_list) == 1)
        zydis_insn = zydis_insn_list[0]
        instruction.bytestring = bytestring
        instruction.archstring = self.archstring
        instruction.ea = zydis_insn.address
        instruction.op_name = zydis_insn.mnemonic
        instruction.asm_string = str(zydis_insn)
        op_list = []
        for zydis_op in zydis_insn.operands:
            if zydis_op.type == pydis.types.OperandType.Register:
                op = acorn.RegisterOperand()
                op.reg = ISARegister.get_reg(zydis_op.register.name.upper())
            elif zydis_op.type == pydis.types.OperandType.Memory:
                op = acorn.MemoryOperand()
                zydis_memop = zydis_op.memory
                op.seg_reg = ISARegister.get_reg(zydis_memop.segment.name.upper())
                op.base_reg = ISARegister.get_reg(zydis_memop.base.name.upper())
                op.index_reg = ISARegister.get_reg(zydis_memop.index.name.upper())
                op.index_scale = zydis_memop.scale
                op.displacement = zydis_memop.displacement
                op.symbols = []
            elif zydis_op.type == pydis.types.OperandType.Immediate:
                op = acorn.ImmediateOperand()
                op.imm = zydis_op.immediate
            else:
                raise Exception('Operand type not implemented!')
            op.access = Access(zydis_op.action)
            op.data_type = 0    # unknown data type
            op_list.append(op)
        instruction.operands = op_list
        return instruction

class SquirrelDisassemblerCapstone(object):
    def __init__(self, archstring):
        check_type(archstring, str)
        self.archstring = archstring
        if archstring == 'X86':
            self.cs = capstone.Cs(capstone.CS_ARCH_X86, capstone.CS_MODE_32)
        elif archstring == 'AMD64':
            self.cs = capstone.Cs(capstone.CS_ARCH_X86, capstone.CS_MODE_64)
        elif archstring == 'AArch32':
            raise Exception('Architecture not supported!')
        elif archstring == 'AArch64':
            raise Exception('Architecture not supported!')
        else:
            raise Exception('Architecture not supported!')
        self.cs.detail = True

    def _get_reg(self, capstone_insn, capstone_reg):
        ISARegister = get_register_arch(self.archstring)
        name = capstone_insn.reg_name(capstone_reg)
        if name:
            return ISARegister.get_reg(name.upper())

    def disassemble(self, bytestring, ea=0x1000):
        ISARegister = get_register_arch(self.archstring)
        instruction = acorn.Instruction()
        rawbytes = bytes.fromhex(bytestring)
        capstone_insn = next(self.cs.disasm(rawbytes, ea))
        instruction.bytestring = bytestring
        instruction.archstring = self.archstring
        instruction.ea = capstone_insn.address
        instruction.op_name = capstone_insn.mnemonic
        instruction.asm_string = '{} {}'.format(capstone_insn.mnemonic,
                capstone_insn.op_str).rstrip()
        op_list = []
        for capstone_op in capstone_insn.operands:
            if capstone_op.type == capstone.CS_OP_REG:
                op = acorn.RegisterOperand()
                op.reg = self._get_reg(capstone_insn, capstone_op.reg)
            elif capstone_op.type == capstone.CS_OP_MEM:
                op = acorn.MemoryOperand()
                capstone_memop = capstone_op.mem
                op.seg_reg = self._get_reg(capstone_insn, capstone_memop.segment)
                op.base_reg = self._get_reg(capstone_insn, capstone_memop.base)
                op.index_reg = self._get_reg(capstone_insn, capstone_memop.index)
                op.index_scale = capstone_memop.scale
                op.displacement = capstone_memop.disp
                op.symbols = []
            elif capstone_op.type == capstone.CS_OP_IMM:
                op = acorn.ImmediateOperand()
                op.imm = capstone_op.imm
            capstone_access = 0
            if capstone_op.access == capstone.CS_AC_READ:
                capstone_access |= Access.Read.value
            if capstone_op.access == capstone.CS_AC_WRITE:
                capstone_access |= Access.Write.value
            op.access = Access(capstone_access)
            op.data_type = 0    # unknown data type
            op_list.append(op)
        instruction.operands = op_list
        return instruction


