import json
import time
import hashlib
import zlib

from enum import IntEnum
from collections import Iterable

from squirrel import Access
from squirrel.squirrel_serializer.jsonable import JSONAble
from squirrel.isa.registers import get_register_arch, MemorySlot

import pdb

class AcornType(object):
    CFG = 'CFG'
    DFG = 'DFG'
    CALLGRAPH = 'CallGraph'
    FUNCTION = 'Function'
    BASICBLOCK = 'BasicBlock'
    INSN = 'Instruction'
    OPERAND = 'Operand'
    MEM = 'Memory'
    SECTION = 'Section'
    MODINFO = 'ModuleInfo'
    BINGRAPH = 'BinGraph'
    EDGE = 'Edge'
    RELOC_INFO = 'RelocationInfo'
    HEADER_INFO = 'HeaderInfo'
    TYPE_LIB = 'TypeLibrary'

def _hash(obj):
    sha256 = hashlib.sha256()
    if isinstance(obj, Acorn):
        return obj.hash()

    if isinstance(obj, dict):
        hash_list = []
        for key, value in obj.items():
            hash_list.append(_hash(value))
        hash_list.sort()
        for hash_ in hash_list:
            sha256.update(hash_.encode())
    elif isinstance(obj, str):
        return str(hash(obj))
    elif isinstance(obj, Iterable):
        hash_list = []
        for value in obj:
            hash_list.append(_hash(value))
        for hash_ in hash_list:
            sha256.update(hash_.encode())
    else:
        try:
            hash_ = hash(obj)
            if isinstance(hash_, int):
                hash_ = str(hash_)
            return hash_
        except:
            pass
        print("Unhandled HASH type!")
        assert(False)
    hash_ = sha256.hexdigest()
    return hash_


class Acorn(JSONAble):
    def __init__(self):
        self.acorn_timestamp    = time.time()
        self.acorn_type         = self.__class__.__name__
        self.acorn_summary      = None
        self.acorn_confidence   = None
        self.acorn_dependency   = set()
        self.acorn_hash         = None

    def merge(self):
        raise NotImplementedError

    def hash(self, cache=True):
        if cache and self.acorn_hash:
            return self.acorn_hash

        sha256 = hashlib.sha256()
        hash_list = []
        for key, value in self.__dict__.items():
            if 'acorn' in key:
                continue
            hash_list.append(_hash(value))
        for hash_ in sorted(hash_list):
            sha256.update(hash_.encode())
        return sha256.hexdigest()

class Condition(Acorn):
    class CondOps(IntEnum):
        DNF=1
        LOGIC=2
        CMP=3

    def __init__(self, cond_op=None, cond_criteria=None):
        super().__init__()
        self.cond_op        = cond_op
        self.cond_criteria  = cond_criteria

    def evaluate(self, value):
        _OPS_FN_MAP = {
            CondOps.DNF     : self._dnf_eval,
            CondOps.LOGIC   : self._logic_eval,
            CondOps.CMP     : self._cmp_eval
        }
        return _OPS_FN_MAP[self.cond_type](value)

    def _dnf_eval(self, value):
        # value consists of a list of tuples representing the boolean function in DNF
        # each tuple is (mask, criteria), return true if value satisfy any tuple
        return any([value & mask == criteria for mask, criteria in self.cond_criteria])

    def _logic_eval(self, value):
        raise NotImplementedError

    def _cmp_eval(self, value):
        raise NotImplementedError

    def __str__(self):
        rep = 'Condition: {}'.format(Condition.CondOps(self.cond_op).name)
        for mask, criteria in self.cond_criteria:
            rep += '\nMask: {} \t\tCriteria: {}'.format(mask, criteria)
        return rep

class StateFormat(Acorn):
    def __init__(self, archstring=None, reg_list=[], mem_list=[]):
        super().__init__()
        self.archstring     = archstring
        self.reg_list       = reg_list
        self.mem_list       = mem_list

    @property
    def bit_size(self):
        assert(self.archstring)
        ISARegister = get_register_arch(self.archstring)
        bit_size = 0
        for reg in self.reg_list:
            bit_size += ISARegister.get_reg_size(reg)
        for mem in self.mem_list:
            bit_size += MemorySlot.get_size(mem) * 8
        return bit_size

    def reg2pos(self, reg):
        assert(self.archstring)
        ISARegister = get_register_arch(self.archstring)
        pos = 0
        for reg2 in self.reg_list:
            if reg == reg2:
                break
            pos += ISARegister.get_reg_size(reg2)
        return pos

    def pos2entity(self, pos):
        assert(self.archstring)
        ISARegister = get_register_arch(self.archstring)
        for reg in self.reg_list:
            reg_size = ISARegister.get_reg_size(reg)
            pos -= reg_size
            if pos < 0:
                return ('REG', reg, pos+reg_size)
        for mem in self.mem_list:
            mem_size = MemorySlot.get_size(mem)*8
            pos -= mem_size
            if pos < 0:
                return ('MEM', mem, pos+reg_size)

    def pos2entity_str(self, pos):
        assert(self.archstring)
        ISARegister = get_register_arch(self.archstring)
        entity_type, entity, entity_offset = self.pos2entity(pos)
        if entity_type == 'REG':
            name = ISARegister.get_reg_name(entity)
        elif entity_type == 'MEM':
            name = MemorySlot.mem2str(entity)
        entity_name = "{}[{}]".format(name, entity_offset)
        return entity_name

    def __str__(self):
        assert(self.archstring)
        ISARegister = get_register_arch(self.archstring)
        reg_str_list = []
        for reg in self.reg_list:
            reg_name = ISARegister.get_reg_name(reg)
            reg_size = ISARegister.get_reg_size(reg)
            reg_str_list.append('({}:{})'.format(reg_name, reg_size))
        reg_str = ' | '.join(reg_str_list)
        mem_str_list = []
        for mem in self.mem_list:
            mem_str_list.append('({}:{})'.format(MemorySlot.mem2str(mem),
                MemorySlot.get_size(mem)*8))
        mem_str = ' | '.join(mem_str_list)
        rep = 'StateFormat: [{}] : [{}] - [{}]'.format(self.archstring, reg_str, mem_str)
        return rep

class TaintRule(Acorn):
    def __init__(self, state_format=StateFormat(), conditions=[]):
        super().__init__()
        self.state_format   = state_format
        self.conditions     = conditions
        self.dataflows      = [{}]

        if conditions:
            for _ in range(len(conditions)):
                self.dataflows.append({})
            for dataflow in self.dataflows:
                for pos in range(state_format.bit_size):
                    dataflow[pos] = set()

    def __dataflow_str(self, dataflow):
        rep = ''
        for use_pos in sorted(dataflow):
            entity_name = self.state_format.pos2entity_str(use_pos)
            flow_str = '{}\t: {}\t--> {}'.format(entity_name, use_pos, dataflow[use_pos])
            rep += '{}\n'.format(flow_str)
        return rep

    def __str__(self):
        rep = '{}\n'.format(self.state_format)
        for cond_id, condition in enumerate(self.conditions):
            rep += '{}\nDataflows\n'.format(condition)
            rep += self.__dataflow_str(self.dataflows[cond_id])
        rep += '\n[True]\nDataflows\n'
        rep += self.__dataflow_str(self.dataflows[-1])
        return rep


class ControlFlowGraph(Acorn):
    def __init__(self):
        super().__init__()
        self.normal_flows   = None
        self.branch_flows   = None
        self.indirect_flows = None

    def get_next_insns(self, ea):
        result = []
        if self.normal_flows[ea]:
            result.append(self.normal_flows[ea])
        if self.branch_flows[ea]:
            for dst in self.branch_flows[ea]:
                result.append(dst)
        if self.indirect_flows[ea]:
            result.append(self.indirect_flows[ea])
        return result

    def get_next_bb(self, ea):
        cur_ea = ea
        while (not self.branch_flows[cur_ea] and not self.indirect_flows[ea]):
            cur_ea = self.normal_flows[ea]
        return self.get_next_insns(cur_ea)

class Flow(Acorn):
    class FlowType(IntEnum):
        ControlFlow = 0
        DataFlow = 1

    def __init__(self):
        super().__init__()
        self.src            = None
        self.dst            = None
        self.flow_type      = None

class BasicBlock(Acorn):
    def __init__(self):
        super().__init__()
        self.insn_list      = None

class Instruction(Acorn):
    def __init__(self):
        super().__init__()
        self.bytestring     = None
        self.archstring     = None
        self.asm_string     = None
        self.ea             = None
        self.op_name        = None
        self.operands       = None

    def reg_reads(self):
        result = set()
        for op in self.operands:
            if isinstance(op, RegisterOperand):
                if (op.access == Access.CondRead or
                    op.access == Access.Read or
                    op.access == Access.Read_CondWrite or
                    op.access == Access.Read_Write or
                    op.access == Access.Write_CondRead):
                    result.add(op.reg)
            elif isinstance(op, MemoryOperand):
                if op.base_reg:
                    result.add(op.base_reg)
                if op.index_reg:
                    result.add(op.index_reg)
        return result

    def reg_writes(self):
        result = set()
        for op in self.operands:
            if isinstance(op, RegisterOperand):
                if (op.access == Access.CondWrite or
                    op.access == Access.Write or
                    op.access == Access.Read_CondWrite or
                    op.access == Access.Read_Write or
                    op.access == Access.Write_CondRead):
                    result.add(op.reg)
        return result

class Operand(Acorn):
    def __init__(self):
        super().__init__()
        self.op_type        = None
        self.data_type      = None
        self.access         = None

class ImmediateOperand(Operand):
    def __init__(self):
        super().__init__()
        self.imm            = None

class RegisterOperand(Operand):
    def __init__(self):
        super().__init__()
        self.reg            = None

class MemoryOperand(Operand):
    def __init__(self):
        super().__init__()
        self.mem_type       = None
        self.ea             = None
        self.seg_reg        = None
        self.base_reg       = None
        self.index_reg      = None
        self.index_scale    = None
        self.displacement   = None
        self.size           = None

class MemoryReference(Acorn):
    def __init__(self):
        super().__init__()
        self.ea             = None
        self.seg_reg        = None
        self.base_reg       = None
        self.index_reg      = None
        self.index_scale    = None
        self.displacement   = None
        self.size           = None
