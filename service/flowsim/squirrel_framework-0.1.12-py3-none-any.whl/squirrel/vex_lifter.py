#!/usr/bin/env python3

from squirrel.vex_parser import *

import sys
import networkx as nx
import json
from networkx.drawing.nx_agraph import write_dot

import squirrel.isa.registers as isa
import squirrel.acorn.acorns_obj_pb2 as acorn_obj

def vex_eflags(var):
    cooked_var = var
    if 'CC_' in var:
        cooked_var = None
        # TODO: See hack in vex_parser.py
        # if 'CC_OP' in var:
        #     cooked_var = None
        # else:
        #     cooked_var = 'EFLAGS'
    elif 'JUMP' in var:
        cooked_var = None
    elif 'IMM' in var:
        cooked_var = 'IMM'
    return cooked_var

def raw2cook(reg_list):
    cooked_dict = {}
    for def_var in reg_list:
        cooked_var = '_'.join(def_var.split('_')[:-1]).upper()
        #print("raw:{}".format(def_var))
        #print("cook:{}".format(cooked_var))
        cooked_var = vex_eflags(cooked_var)
        if not cooked_var:
            continue
        if cooked_var not in cooked_dict:
            cooked_dict[cooked_var] = []
        for use_var in reg_list[def_var]:
            cooked_use = '_'.join(use_var.split('_')[:-1]).upper()
            cooked_use = vex_eflags(cooked_use)
            if cooked_use and cooked_use not in cooked_dict[cooked_var]:
                cooked_dict[cooked_var].append(cooked_use)
    return cooked_dict

def get_def_use(asg):
    def_use = {}
    def_nodes = [x for x in asg.nodes() if asg.out_degree(x) == 0 and 'tmp' not in x]
    for def_node in def_nodes:
        use_nodes = [x for x in nx.ancestors(asg, def_node) if asg.in_degree(x) == 0 and "tmp" not in x]
        def_use[def_node] = use_nodes
    return def_use

def get_use_def(asg):
    use_def = {}
    use_nodes = [x for x in asg.nodes() if asg.in_degree(x) == 0 and 'tmp' not in x]
    for use_node in use_nodes:
        def_nodes = [x for x in nx.descendants(asg, use_node) if
                asg.out_degree(x) == 0 and 'tmp' not in x]
        use_def[use_node] = def_nodes
    return use_def

def create_dfg(fn_graph):
    fn_dfg = nx.DiGraph()
    workset = []
    visited = set()
    asgs = {}
    dfg = {}
    for entry_node in fn_graph['ENTRY']:
        workset.append(entry_node)
    while (workset):
        current_node = workset.pop()
        visited.add(current_node)
        byte_string = fn_graph.node[current_node]['raw_bytes']
        rawbytes = bytes.fromhex(byte_string)
        asgs[current_node] = parse_rawbytes(rawbytes, current_node)
        for next_node in fn_graph[current_node]:
            if next_node not in visited:
                workset.append(next_node)
    for addr in asgs:
        print('DEF_USE: {} ---- {}'.format(hex(addr), fn_graph.node[addr]['raw_bytes']))
        raw = get_def_use(asgs[addr])
        cooked = raw2cook(raw)
        dfg[addr] = cooked
        write_dot(asgs[addr], 'dump/{}'.format(fn_graph.node[addr]['raw_bytes']))
    return dfg

def defuse_bytes(rawbytes, addr, arch):
    set_arch(arch)
    global DEBUG
    asg = parse_rawbytes(rawbytes, addr, DEBUG)
    defuse = raw2cook(get_def_use(asg))
    return defuse

def usedef_bytes(rawbytes, addr, arch):
    set_arch(arch)
    #asg = parse_rawbytes(rawbytes, addr, True)
    asg = parse_rawbytes(rawbytes, addr, False)
    usedef = raw2cook(get_use_def(asg))
    return usedef

def convert_name(reg_name, aux_stuff, skip_condition=True):
    current_isa, reg_list, mem_list = aux_stuff
    if "MEM" in reg_name:
        reg = isa.MemorySlot.str2mem(reg_name)
        mem_list.add(reg)
    elif reg_name == 'IMM':
        reg = 0
    elif skip_condition and reg_name == "CPSR" or reg_name == "EFLAGS":
        reg = None
    else:
        reg = current_isa.get_reg(reg_name)
        reg_list.add(reg)
    return reg

def get_flow(archstring, addr, bytestring):
    current_isa = isa.get_register_arch(archstring.upper())
    rawbytes = bytes.fromhex(bytestring)
    defuse = defuse_bytes(rawbytes, addr, archstring)
    usedef = usedef_bytes(rawbytes, addr, archstring)
    #print(defuse)
    #print(usedef)
    qq = {}
    reg_list = set()
    mem_list = set()
    aux_stuff = (current_isa, reg_list, mem_list)
    reg_dep = usedef
    for reg_key in reg_dep:
        reg_key_val = convert_name(reg_key, aux_stuff)
        if reg_key_val == None:
            continue
        qq[reg_key_val] = set()
        for reg_data in reg_dep[reg_key]:
            reg_data_val = convert_name(reg_data, aux_stuff)
            if reg_data_val == None:
                continue
            qq[reg_key_val].add(reg_data_val)

    taintrule = acorn_obj.TaintRule()
    taintrule.state_format.archstring = archstring
    taintrule.state_format.reg_list.extend(reg_list)
    taintrule.state_format.mem_list.extend(mem_list)

    reg_list = taintrule.state_format.reg_list
    mem_list = taintrule.state_format.mem_list

    # get the big list of numbers
    reg_to_num = {}
    cur_num = 0
    for reg in reg_list:
        size = current_isa.get_reg_size(reg)
        reg_to_num[reg] = (cur_num, size)
        cur_num += size

    for mem in mem_list:
        size = isa.MemorySlot.get_size(mem) * 8
        reg_to_num[mem] = (cur_num, size)
        cur_num += size

    # create the flows
    for reg in qq:
        if reg == 0:
            continue
        start_num, size = reg_to_num[reg]
        reg_positions = range(start_num, start_num + size)
        for reg_position in reg_positions:
            use_def = acorn_obj.UseDef()
            use_def.use = reg_position
            for reg2 in qq[reg]:
                start_num2, size2 = reg_to_num[reg2]
                reg2_pos = range(start_num2, start_num2 + size2)
                use_def.defs.extend(reg2_pos)
            taintrule.use_def.append(use_def)
    if DEBUG:
        print(qq)
        print('reg_list: {}'.format(reg_list))
        print('mem_list: {}'.format(mem_list))
        print(taintrule)

    return taintrule

DEBUG = False

def main():
    global DEBUG
    DEBUG = True
    bytestring = sys.argv[1]
    addr = int(sys.argv[2])
    arch = sys.argv[3]
    qq = get_flow(arch, addr, bytestring)


    #with open('{}/{}'.format(vex_rule_path, bytestring), 'w') as defuse_file:
    #    json.dump(defuse, defuse_file)
    #addr = int(sys.argv[2], 16)
    #irsb = pyvex.lift(rawbytes, addr, arch)
    #print(irsb)
    #fn_graph = nx.read_gpickle(sys.argv[1])
    #create_dfg(fn_graph)
    #print('-----------------')
    #print(defuse_bytes(bytes.fromhex("e8def9ffff"), 0x4017d1))

if __name__ == '__main__':
    main()

