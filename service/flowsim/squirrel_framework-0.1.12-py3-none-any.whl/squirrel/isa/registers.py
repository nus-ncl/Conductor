from enum import IntEnum

def get_register_arch(obj_name):
    isa2reg = { 'X86'       : X86Register,
                'AMD64'     : X86Register,
                'AARCH32'   : AArch32Register}
    return isa2reg[obj_name.upper()]

class MemorySlot(object):
    READ    = 1
    WRITE   = 0
    VALUE   = 1
    ADDR    = 0

    @staticmethod
    def get_size(val):
        return val >> 16

    @staticmethod
    def get_slot(val):
        return val & 16383

    @staticmethod
    def get_access(val):
        return int(bool(val & 32768))

    @staticmethod
    def get_slot_type(val):
        return int(bool(val & 16384))


    @staticmethod
    def get_mem(slot_num, access, size, slot_type):
        assert(slot_num < 16384)
        assert(access == 0 or access == 1)
        val = slot_num
        val |= (access * 32768)
        val |= (slot_type * 16384)
        val |= size << 16
        return val

    @staticmethod
    def mem2str(val):
        slot_num = MemorySlot.get_slot(val)
        size = MemorySlot.get_size(val)
        access = 'READ' if MemorySlot.get_access(val) else 'WRITE'
        slot_type = 'VALUE' if MemorySlot.get_slot_type(val) else 'ADDR'

        mem_str = 'MEM_{}_{}_{}_{}'.format(access, slot_num, slot_type, size)
        return mem_str

    @staticmethod
    def str2mem(mem_str):
        mem_token = mem_str.split('_')
        magic_num, access, slot_num, slot_type, size = mem_token
        assert(magic_num == 'MEM')
        slot_num = int(slot_num)
        access = 1 if access == 'READ' else 0
        slot_type = 1 if slot_type == 'VALUE' else 0
        return MemorySlot.get_mem(int(slot_num), access, int(size), slot_type)


class Register(object):
    @staticmethod
    def get_reg(reg_name):
        raise NotImplementedError()

    @staticmethod
    def get_reg_name(reg):
        raise NotImplementedError()

    @staticmethod
    def enclosing_reg(reg):
        raise NotImplementedError()

    @staticmethod
    def get_reg_size(reg):
        raise NotImplementedError()

class AArch32Register(Register):
    INVALID = 0
    R0 = 1
    R1 = 2
    R2 = 3
    R3 = 4
    R4 = 5
    R5 = 6
    R6 = 7
    R7 = 8
    R8 = 9
    R9 = 10
    R10 = 11
    R11 = 12
    R12 = 13
    R13 = 14
    R14 = 15
    R15 = 16
    # Aliases
    A1 = 1
    A2 = 2
    A3 = 3
    A4 = 4
    V1 = 5
    V2 = 6
    V3 = 7
    V4 = 8
    WR = 8
    V5 = 9
    V6 = 10
    SB = 10
    V7 = 11
    SL = 11
    V8 = 12
    FP = 12
    IP = 13
    SP = 14
    LR = 15
    PC = 16
    APSR = 37
    CPSR = 38
    # Floating point registers
    S0 = 39
    S1 = 40
    S2 = 41
    S3 = 42
    S4 = 43
    S5 = 44
    S6 = 45
    S7 = 46
    S8 = 47
    S9 = 48
    S10 = 49
    S11 = 50
    S12 = 51
    S13 = 52
    S14 = 53
    S15 = 54
    S16 = 55
    S17 = 56
    S18 = 57
    S19 = 58
    S20 = 59
    S21 = 60
    S22 = 61
    S23 = 62
    S24 = 63
    S25 = 64
    S26 = 65
    S27 = 66
    S28 = 67
    S29 = 68
    S30 = 69
    S31 = 70
    D0 = 71
    D1 = 72
    D2 = 73
    D3 = 74
    D4 = 75
    D5 = 76
    D6 = 77
    D7 = 78
    D8 = 79
    D9 = 80
    D10 = 81
    D11 = 82
    D12 = 83
    D13 = 84
    D14 = 85
    D15 = 86

    reg_map = {
        'INVALID': INVALID,
        'R0': R0,
        'R1': R1,
        'R2': R2,
        'R3': R3,
        'R4': R4,
        'R5': R5,
        'R6': R6,
        'R7': R7,
        'R8': R8,
        'R9': R9,
        'R10': R10,
        'R11': R11,
        'R12': R12,
        'R13': R13,
        'R14': R14,
        'R15': R15,
        'A1': A1,
        'A2': A2,
        'A3': A3,
        'A4': A4,
        'V1': V1,
        'V2': V2,
        'V3': V3,
        'V4': V4,
        'WR': WR,
        'V5': V5,
        'V6': V6,
        'SB': SB,
        'V7': V7,
        'SL': SL,
        'V8': V8,
        'FP': FP,
        'IP': IP,
        'SP': SP,
        'LR': LR,
        'PC': PC,
        'APSR': APSR,
        'CPSR': CPSR,
        'S0': S0,
        'S1': S1,
        'S2': S2,
        'S3': S3,
        'S4': S4,
        'S5': S5,
        'S6': S6,
        'S7': S7,
        'S8': S8,
        'S9': S9,
        'S10': S10,
        'S11': S11,
        'S12': S12,
        'S13': S13,
        'S14': S14,
        'S15': S15,
        'S16': S16,
        'S17': S17,
        'S18': S18,
        'S19': S19,
        'S20': S20,
        'S21': S21,
        'S22': S22,
        'S23': S23,
        'S24': S24,
        'S25': S25,
        'S26': S26,
        'S27': S27,
        'S28': S28,
        'S29': S29,
        'S30': S30,
        'S31': S31,
        'D0': D0,
        'D1': D1,
        'D2': D2,
        'D3': D3,
        'D4': D4,
        'D5': D5,
        'D6': D6,
        'D7': D7,
        'D8': D8,
        'D9': D9,
        'D10': D10,
        'D11': D11,
        'D12': D12,
        'D13': D13,
        'D14': D14,
        'D15': D15
    }

    inverse_reg_map = {
        INVALID: 'INVALID',
        R0 : 'R0',
        R1 : 'R1',
        R2 : 'R2',
        R3 : 'R3',
        R4 : 'R4',
        R5 : 'R5',
        R6 : 'R6',
        R7 : 'R7',
        R8 : 'R8',
        SB : 'SB',
        SL : 'SL',
        FP : 'FP',
        IP : 'IP',
        SP : 'SP',
        LR : 'LR',
        PC : 'PC',
        APSR : 'APSR',
        CPSR : 'CPSR',
        S0: 'S0',
        S1: 'S1',
        S2: 'S2',
        S3: 'S3',
        S4: 'S4',
        S5: 'S5',
        S6: 'S6',
        S7: 'S7',
        S8: 'S8',
        S9: 'S9',
        S10: 'S10',
        S11: 'S11',
        S12: 'S12',
        S13: 'S13',
        S14: 'S14',
        S15: 'S15',
        S16: 'S16',
        S17: 'S17',
        S18: 'S18',
        S19: 'S19',
        S20: 'S20',
        S21: 'S21',
        S22: 'S22',
        S23: 'S23',
        S24: 'S24',
        S25: 'S25',
        S26: 'S26',
        S27: 'S27',
        S28: 'S28',
        S29: 'S29',
        S30: 'S30',
        S31: 'S31',
        D0: 'D0',
        D1: 'D1',
        D2: 'D2',
        D3: 'D3',
        D4: 'D4',
        D5: 'D5',
        D6: 'D6',
        D7: 'D7',
        D8: 'D8',
        D9: 'D9',
        D10: 'D10',
        D11: 'D11',
        D12: 'D12',
        D13: 'D13',
        D14: 'D14',
        D15: 'D15'
    }

    @staticmethod
    def get_reg(arm_reg):
        """ @param arm_reg: String type
        Convert to a AArch32Reg type """
        if arm_reg not in AArch32Register.reg_map:
            raise Exception('Register name not found!')
        return AArch32Register.reg_map[arm_reg]

    @staticmethod
    def get_reg_name(reg):
        """ @param reg: AArch32Reg type
            Convert AArch32Reg to its string name
        """
        if reg not in AArch32Register.inverse_reg_map:
            raise Exception('Register not found!')
        return AArch32Register.inverse_reg_map[reg]

    @staticmethod
    def is_64bit_register(reg):
        """
            Returns true if @reg is a double precision register
            eg. D0, D1, ... , D15
        """
        if AArch32Register.D0 <= reg <= ArmReg.D15:
            return True
        return False


class X86Register(Register):
    INVALID = 0
    AH = 1
    AL = 2
    BH = 3
    BL = 4
    BPL = 5
    CH = 6
    CL = 7
    CS = 8
    DH = 9
    DIL = 10
    DL = 11
    DS = 12
    SIL = 13
    SPL = 14

    AX = 15
    BX = 16
    CX = 17
    DX = 18
    DI = 19
    BP = 20
    SI = 21
    SP = 22

    EAX = 23
    EBP = 24
    EBX = 25
    ECX = 26
    EDI = 27
    EDX = 28
    EFLAGS = 29
    EIP = 30
    EIZ = 31
    ES = 32
    ESI = 33
    ESP = 34
    FPSW = 35
    FS = 36
    GS = 37
    IP = 38
    RAX = 39
    RBP = 40
    RBX = 41
    RCX = 42
    RDI = 43
    RDX = 44
    RIP = 45
    RIZ = 46
    RSI = 47
    RSP = 48
    RFLAGS = 501

    SS = 49
    CR0 = 50
    CR1 = 51
    CR2 = 52
    CR3 = 53
    CR4 = 54
    CR5 = 55
    CR6 = 56
    CR7 = 57
    CR8 = 58
    CR9 = 59
    CR10 = 60
    CR11 = 61
    CR12 = 62
    CR13 = 63
    CR14 = 64
    CR15 = 65
    DR0 = 66
    DR1 = 67
    DR2 = 68
    DR3 = 69
    DR4 = 70
    DR5 = 71
    DR6 = 72
    DR7 = 73
    FP0 = 74
    FP1 = 75
    FP2 = 76
    FP3 = 77
    FP4 = 78
    FP5 = 79
    FP6 = 80
    FP7 = 81
    K0 = 82
    K1 = 83
    K2 = 84
    K3 = 85
    K4 = 86
    K5 = 87
    K6 = 88
    K7 = 89
    MM0 = 90
    MM1 = 91
    MM2 = 92
    MM3 = 93
    MM4 = 94
    MM5 = 95
    MM6 = 96
    MM7 = 97
    R8 = 98
    R9 = 99
    R10 = 100
    R11 = 101
    R12 = 102
    R13 = 103
    R14 = 104
    R15 = 105
    ST = 500
    ST0 = 106
    ST1 = 107
    ST2 = 108
    ST3 = 109
    ST4 = 110
    ST5 = 111
    ST6 = 112
    ST7 = 113
    XMM0 = 114
    XMM1 = 115
    XMM2 = 116
    XMM3 = 117
    XMM4 = 118
    XMM5 = 119
    XMM6 = 120
    XMM7 = 121
    XMM8 = 122
    XMM9 = 123
    XMM10 = 124
    XMM11 = 125
    XMM12 = 126
    XMM13 = 127
    XMM14 = 128
    XMM15 = 129
    XMM16 = 130
    XMM17 = 131
    XMM18 = 132
    XMM19 = 133
    XMM20 = 134
    XMM21 = 135
    XMM22 = 136
    XMM23 = 137
    XMM24 = 138
    XMM25 = 139
    XMM26 = 140
    XMM27 = 141
    XMM28 = 142
    XMM29 = 143
    XMM30 = 144
    XMM31 = 145
    YMM0 = 146
    YMM1 = 147
    YMM2 = 148
    YMM3 = 149
    YMM4 = 150
    YMM5 = 151
    YMM6 = 152
    YMM7 = 153
    YMM8 = 154
    YMM9 = 155
    YMM10 = 156
    YMM11 = 157
    YMM12 = 158
    YMM13 = 159
    YMM14 = 160
    YMM15 = 161
    YMM16 = 162
    YMM17 = 163
    YMM18 = 164
    YMM19 = 165
    YMM20 = 166
    YMM21 = 167
    YMM22 = 168
    YMM23 = 169
    YMM24 = 170
    YMM25 = 171
    YMM26 = 172
    YMM27 = 173
    YMM28 = 174
    YMM29 = 175
    YMM30 = 176
    YMM31 = 177
    ZMM0 = 178
    ZMM1 = 179
    ZMM2 = 180
    ZMM3 = 181
    ZMM4 = 182
    ZMM5 = 183
    ZMM6 = 184
    ZMM7 = 185
    ZMM8 = 186
    ZMM9 = 187
    ZMM10 = 188
    ZMM11 = 189
    ZMM12 = 190
    ZMM13 = 191
    ZMM14 = 192
    ZMM15 = 193
    ZMM16 = 194
    ZMM17 = 195
    ZMM18 = 196
    ZMM19 = 197
    ZMM20 = 198
    ZMM21 = 199
    ZMM22 = 200
    ZMM23 = 201
    ZMM24 = 202
    ZMM25 = 203
    ZMM26 = 204
    ZMM27 = 205
    ZMM28 = 206
    ZMM29 = 207
    ZMM30 = 208
    ZMM31 = 209
    R8B = 210
    R9B = 211
    R10B = 212
    R11B = 213
    R12B = 214
    R13B = 215
    R14B = 216
    R15B = 217
    R8D = 218
    R9D = 219
    R10D = 220
    R11D = 221
    R12D = 222
    R13D = 223
    R14D = 224
    R15D = 225
    R8W = 226
    R9W = 227
    R10W = 228
    R11W = 229
    R12W = 230
    R13W = 231
    R14W = 232
    R15W = 233

    reg_map = {
        'AH': AH, 'AL': AL, 'AX': AX, 'BH': BH, 
        'BL': BL, 'BP': BP, 'BPL': BPL, 'BX': BX, 
        'CH': CH, 'CL': CL, 'CS': CS, 'CX': CX, 
        'DH': DH, 'DI': DI, 'DIL': DIL, 'DL': DL, 
        'DS': DS, 'DX': DX, 'EAX': EAX, 'EBP': EBP, 
        'EBX': EBX, 'ECX': ECX, 'EDI': EDI, 'EDX': EDX, 
        'EFLAGS': EFLAGS, 'EIP': EIP, 'EIZ': EIZ, 'ES': ES, 
        'ESI': ESI, 'ESP': ESP, 'FPSW': FPSW, 'FS': FS, 
        'GS': GS, 'IP': IP, 'RAX': RAX, 'RBP': RBP, 
        'RBX': RBX, 'RCX': RCX, 'RDI': RDI, 'RDX': RDX, 
        'RIP': RIP, 'RIZ': RIZ, 'RSI': RSI, 'RSP': RSP, 
        'SI': SI, 'SIL': SIL, 'SP': SP, 'SPL': SPL, 
        'SS': SS, 'CR0': CR0, 'CR1': CR1, 'CR2': CR2, 
        'CR3': CR3, 'CR4': CR4, 'CR5': CR5, 'CR6': CR6, 
        'CR7': CR7, 'CR8': CR8, 'CR9': CR9, 'CR10': CR10, 
        'CR11': CR11, 'CR12': CR12, 'CR13': CR13, 'CR14': CR14, 
        'CR15': CR15, 'DR0': DR0, 'DR1': DR1, 'DR2': DR2, 
        'DR3': DR3, 'DR4': DR4, 'DR5': DR5, 'DR6': DR6, 
        'DR7': DR7, 'FP0': FP0, 'FP1': FP1, 'FP2': FP2, 
        'FP3': FP3, 'FP4': FP4, 'FP5': FP5, 'FP6': FP6, 
        'FP7': FP7, 'K0': K0, 'K1': K1, 'K2': K2, 
        'K3': K3, 'K4': K4, 'K5': K5, 'K6': K6, 
        'K7': K7, 'MM0': MM0, 'MM1': MM1, 'MM2': MM2, 
        'MM3': MM3, 'MM4': MM4, 'MM5': MM5, 'MM6': MM6, 
        'MM7': MM7, 'R8': R8, 'R9': R9, 'R10': R10, 
        'R11': R11, 'R12': R12, 'R13': R13, 'R14': R14, 
        'R15': R15, 'ST': ST, 'ST0': ST0, 'ST1': ST1, 'ST2': ST2, 
        'ST3': ST3, 'ST4': ST4, 'ST5': ST5, 'ST6': ST6, 
        'ST7': ST7, 'XMM0': XMM0, 'XMM1': XMM1, 'XMM2': XMM2, 
        'XMM3': XMM3, 'XMM4': XMM4, 'XMM5': XMM5, 'XMM6': XMM6, 
        'XMM7': XMM7, 'XMM8': XMM8, 'XMM9': XMM9, 'XMM10': XMM10, 
        'XMM11': XMM11, 'XMM12': XMM12, 'XMM13': XMM13, 'XMM14': XMM14, 
        'XMM15': XMM15, 'XMM16': XMM16, 'XMM17': XMM17, 'XMM18': XMM18, 
        'XMM19': XMM19, 'XMM20': XMM20, 'XMM21': XMM21, 'XMM22': XMM22, 
        'XMM23': XMM23, 'XMM24': XMM24, 'XMM25': XMM25, 'XMM26': XMM26, 
        'XMM27': XMM27, 'XMM28': XMM28, 'XMM29': XMM29, 'XMM30': XMM30, 
        'XMM31': XMM31, 'YMM0': YMM0, 'YMM1': YMM1, 'YMM2': YMM2, 
        'YMM3': YMM3, 'YMM4': YMM4, 'YMM5': YMM5, 'YMM6': YMM6, 
        'YMM7': YMM7, 'YMM8': YMM8, 'YMM9': YMM9, 'YMM10': YMM10, 
        'YMM11': YMM11, 'YMM12': YMM12, 'YMM13': YMM13, 'YMM14': YMM14, 
        'YMM15': YMM15, 'YMM16': YMM16, 'YMM17': YMM17, 'YMM18': YMM18, 
        'YMM19': YMM19, 'YMM20': YMM20, 'YMM21': YMM21, 'YMM22': YMM22, 
        'YMM23': YMM23, 'YMM24': YMM24, 'YMM25': YMM25, 'YMM26': YMM26, 
        'YMM27': YMM27, 'YMM28': YMM28, 'YMM29': YMM29, 'YMM30': YMM30, 
        'YMM31': YMM31, 'ZMM0': ZMM0, 'ZMM1': ZMM1, 'ZMM2': ZMM2, 
        'ZMM3': ZMM3, 'ZMM4': ZMM4, 'ZMM5': ZMM5, 'ZMM6': ZMM6, 
        'ZMM7': ZMM7, 'ZMM8': ZMM8, 'ZMM9': ZMM9, 'ZMM10': ZMM10, 
        'ZMM11': ZMM11, 'ZMM12': ZMM12, 'ZMM13': ZMM13, 'ZMM14': ZMM14, 
        'ZMM15': ZMM15, 'ZMM16': ZMM16, 'ZMM17': ZMM17, 'ZMM18': ZMM18, 
        'ZMM19': ZMM19, 'ZMM20': ZMM20, 'ZMM21': ZMM21, 'ZMM22': ZMM22, 
        'ZMM23': ZMM23, 'ZMM24': ZMM24, 'ZMM25': ZMM25, 'ZMM26': ZMM26, 
        'ZMM27': ZMM27, 'ZMM28': ZMM28, 'ZMM29': ZMM29, 'ZMM30': ZMM30, 
        'ZMM31': ZMM31, 'R8B': R8B, 'R9B': R9B, 'R10B': R10B, 
        'R11B': R11B, 'R12B': R12B, 'R13B': R13B, 'R14B': R14B, 
        'R15B': R15B, 'R8D': R8D, 'R9D': R9D, 'R10D': R10D, 
        'R11D': R11D, 'R12D': R12D, 'R13D': R13D, 'R14D': R14D, 
        'R15D': R15D, 'R8W': R8W, 'R9W': R9W, 'R10W': R10W, 
        'R11W': R11W, 'R12W': R12W, 'R13W': R13W, 'R14W': R14W, 
        'R15W': R15W, 'RFLAGS': RFLAGS
    }

    inverse_reg_map = {
        AH: 'AH', AL: 'AL', AX: 'AX', BH: 'BH', 
        BL: 'BL', BP: 'BP', BPL: 'BPL', BX: 'BX', 
        CH: 'CH', CL: 'CL', CS: 'CS', CX: 'CX', 
        DH: 'DH', DI: 'DI', DIL: 'DIL', DL: 'DL', 
        DS: 'DS', DX: 'DX', EAX: 'EAX', EBP: 'EBP', 
        EBX: 'EBX', ECX: 'ECX', EDI: 'EDI', EDX: 'EDX', 
        EFLAGS: 'EFLAGS', EIP: 'EIP', EIZ: 'EIZ', ES: 'ES', 
        ESI: 'ESI', ESP: 'ESP', FPSW: 'FPSW', FS: 'FS', 
        GS: 'GS', IP: 'IP', RAX: 'RAX', RBP: 'RBP', 
        RBX: 'RBX', RCX: 'RCX', RDI: 'RDI', RDX: 'RDX', 
        RIP: 'RIP', RIZ: 'RIZ', RSI: 'RSI', RSP: 'RSP', 
        SI: 'SI', SIL: 'SIL', SP: 'SP', SPL: 'SPL', 
        SS: 'SS', CR0: 'CR0', CR1: 'CR1', CR2: 'CR2', 
        CR3: 'CR3', CR4: 'CR4', CR5: 'CR5', CR6: 'CR6', 
        CR7: 'CR7', CR8: 'CR8', CR9: 'CR9', CR10: 'CR10', 
        CR11: 'CR11', CR12: 'CR12', CR13: 'CR13', CR14: 'CR14', 
        CR15: 'CR15', DR0: 'DR0', DR1: 'DR1', DR2: 'DR2', 
        DR3: 'DR3', DR4: 'DR4', DR5: 'DR5', DR6: 'DR6', 
        DR7: 'DR7', FP0: 'FP0', FP1: 'FP1', FP2: 'FP2', 
        FP3: 'FP3', FP4: 'FP4', FP5: 'FP5', FP6: 'FP6', 
        FP7: 'FP7', K0: 'K0', K1: 'K1', K2: 'K2', 
        K3: 'K3', K4: 'K4', K5: 'K5', K6: 'K6', 
        K7: 'K7', MM0: 'MM0', MM1: 'MM1', MM2: 'MM2', 
        MM3: 'MM3', MM4: 'MM4', MM5: 'MM5', MM6: 'MM6', 
        MM7: 'MM7', R8: 'R8', R9: 'R9', R10: 'R10', 
        R11: 'R11', R12: 'R12', R13: 'R13', R14: 'R14', 
        R15: 'R15', ST: 'ST', ST0: 'ST0', ST1: 'ST1', ST2: 'ST2', 
        ST3: 'ST3', ST4: 'ST4', ST5: 'ST5', ST6: 'ST6', 
        ST7: 'ST7', XMM0: 'XMM0', XMM1: 'XMM1', XMM2: 'XMM2', 
        XMM3: 'XMM3', XMM4: 'XMM4', XMM5: 'XMM5', XMM6: 'XMM6', 
        XMM7: 'XMM7', XMM8: 'XMM8', XMM9: 'XMM9', XMM10: 'XMM10', 
        XMM11: 'XMM11', XMM12: 'XMM12', XMM13: 'XMM13', XMM14: 'XMM14', 
        XMM15: 'XMM15', XMM16: 'XMM16', XMM17: 'XMM17', XMM18: 'XMM18', 
        XMM19: 'XMM19', XMM20: 'XMM20', XMM21: 'XMM21', XMM22: 'XMM22', 
        XMM23: 'XMM23', XMM24: 'XMM24', XMM25: 'XMM25', XMM26: 'XMM26', 
        XMM27: 'XMM27', XMM28: 'XMM28', XMM29: 'XMM29', XMM30: 'XMM30', 
        XMM31: 'XMM31', YMM0: 'YMM0', YMM1: 'YMM1', YMM2: 'YMM2', 
        YMM3: 'YMM3', YMM4: 'YMM4', YMM5: 'YMM5', YMM6: 'YMM6', 
        YMM7: 'YMM7', YMM8: 'YMM8', YMM9: 'YMM9', YMM10: 'YMM10', 
        YMM11: 'YMM11', YMM12: 'YMM12', YMM13: 'YMM13', YMM14: 'YMM14', 
        YMM15: 'YMM15', YMM16: 'YMM16', YMM17: 'YMM17', YMM18: 'YMM18', 
        YMM19: 'YMM19', YMM20: 'YMM20', YMM21: 'YMM21', YMM22: 'YMM22', 
        YMM23: 'YMM23', YMM24: 'YMM24', YMM25: 'YMM25', YMM26: 'YMM26', 
        YMM27: 'YMM27', YMM28: 'YMM28', YMM29: 'YMM29', YMM30: 'YMM30', 
        YMM31: 'YMM31', ZMM0: 'ZMM0', ZMM1: 'ZMM1', ZMM2: 'ZMM2', 
        ZMM3: 'ZMM3', ZMM4: 'ZMM4', ZMM5: 'ZMM5', ZMM6: 'ZMM6', 
        ZMM7: 'ZMM7', ZMM8: 'ZMM8', ZMM9: 'ZMM9', ZMM10: 'ZMM10', 
        ZMM11: 'ZMM11', ZMM12: 'ZMM12', ZMM13: 'ZMM13', ZMM14: 'ZMM14', 
        ZMM15: 'ZMM15', ZMM16: 'ZMM16', ZMM17: 'ZMM17', ZMM18: 'ZMM18', 
        ZMM19: 'ZMM19', ZMM20: 'ZMM20', ZMM21: 'ZMM21', ZMM22: 'ZMM22', 
        ZMM23: 'ZMM23', ZMM24: 'ZMM24', ZMM25: 'ZMM25', ZMM26: 'ZMM26', 
        ZMM27: 'ZMM27', ZMM28: 'ZMM28', ZMM29: 'ZMM29', ZMM30: 'ZMM30', 
        ZMM31: 'ZMM31', R8B: 'R8B', R9B: 'R9B', R10B: 'R10B', 
        R11B: 'R11B', R12B: 'R12B', R13B: 'R13B', R14B: 'R14B', 
        R15B: 'R15B', R8D: 'R8D', R9D: 'R9D', R10D: 'R10D', 
        R11D: 'R11D', R12D: 'R12D', R13D: 'R13D', R14D: 'R14D', 
        R15D: 'R15D', R8W: 'R8W', R9W: 'R9W', R10W: 'R10W', 
        R11W: 'R11W', R12W: 'R12W', R13W: 'R13W', R14W: 'R14W', 
        R15W: 'R15W', RFLAGS: 'RFLAGS'
    }

    sub_registers = {
        RAX   : [AL,   AH,   AX,   EAX],
        RBX   : [BL,   BH,   BX,   EBX],
        RCX   : [CL,   CH,   CX,   ECX],
        RDX   : [DL,   DH,   DX,   EDX],
        RSI   : [SI,   SIL,  ESI ],
        RDI   : [DI,   DIL,  EDI ],
        RBP   : [BP,   BPL,  EBP ],
        RSP   : [SP,   SPL,  ESP ],
        RFLAGS: [EFLAGS],
        R8    : [R8D,  R8W,  R8B ],
        R9    : [R9D,  R9W,  R9B ],
        R10   : [R10D, R10W, R10B],
        R11   : [R11D, R11W, R11B],
        R12   : [R12D, R12W, R12B],
        R13   : [R13D, R13W, R13B],
        R14   : [R14D, R14W, R14B],
        R15   : [R15D, R15W, R15B],
        RIP   : [IP,   EIP],
        FP0   : [ST0,  MM0,  ST],
        FP1   : [ST1,  MM1],
        FP2   : [ST2,  MM2],
        FP3   : [ST3,  MM3],
        FP4   : [ST4,  MM4],
        FP5   : [ST5,  MM5],
        FP6   : [ST6,  MM6],
        FP7   : [ST7,  MM7]
    }

    @staticmethod
    def get_reg(x86_reg):
        """ @param x86_reg: String type
        Convert to a X86Registerister type """
        x86_reg = x86_reg.upper()
        if x86_reg == 'NONE':
            return None

        # TODO: HACK for hackathon, remove it cleanly 
        hack = x86_reg[-2:]
        if hack == "LQ" or hack == "HQ":
            x86_reg = x86_reg[:-2]
        # end TODO

        if x86_reg not in X86Register.reg_map:
            print('Missing:{}'.format(x86_reg))
            raise Exception('Register name not found!')
        return X86Register.reg_map[x86_reg]

    @staticmethod
    def get_reg_name(reg):
        """ @param reg: X86Register type
            Convert X86Register to its string name
        """
        if reg not in X86Register.inverse_reg_map:
            raise Exception('Register not found!')
        return X86Register.inverse_reg_map[reg]

    @staticmethod
    def is_valid(reg_name):
        reg_name = reg_name.upper()
        return reg_name in X86Register.reg_map

    @staticmethod
    def get_reg_size(reg):
        """ @param reg: X86Register type
            Get the size of the X86Register (eg. 16bit, 32bit, 64bit)
        """
        if X86Register.R8B <= reg <= X86Register.R15B:
            return 8
        elif X86Register.AH <= reg <= X86Register.SPL:
            return 8
        elif X86Register.R8W <= reg <= X86Register.R15W:
            return 16
        elif X86Register.AX <= reg <= X86Register.SP:
            return 16
        elif X86Register.EAX <= reg <= X86Register.ESP:
            return 32
        elif X86Register.R8D <= reg <= X86Register.R15D:
            return 32
        elif X86Register.RAX <= reg <= X86Register.RSP:
            return 64
        elif X86Register.R8 <= reg <= X86Register.R15:
            return 64
        elif X86Register.XMM0 <= reg <= X86Register.XMM31:
            return 128
        elif X86Register.YMM0 <= reg <= X86Register.YMM31:
            return 256
        elif X86Register.ST0 <= reg <= X86Register.ST7:
            return 80
        elif X86Register.FP0 <= reg <= X86Register.FP7:
            return 80
        elif reg == X86Register.ST:
            return 80
        elif reg == X86Register.RFLAGS:
            return 64
        elif reg == X86Register.EFLAGS:
            return 32
        elif reg == X86Register.FS:
            return 64
        else:
            print('Reg:{} not in range'.format(reg))
            raise Exception('Register not in range!')
        return -1

    @staticmethod
    def enclosing_reg(reg):
        for enclose_reg in X86Register.sub_registers:
            if reg in X86Register.sub_registers[enclose_reg]:
                return enclose_reg
