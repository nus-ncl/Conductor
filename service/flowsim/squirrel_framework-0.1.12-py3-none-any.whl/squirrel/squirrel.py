import os
import configparser
import pkgutil

from enum import IntEnum

class Access(IntEnum):
    Invalid = 0
    Read = 1
    Write = 2
    Read_Write = 3
    CondRead = 4
    CondWrite = 5
    Read_CondWrite = 6
    Write_CondRead = 7


#class Register(SquirrelObject):
#    def __init__(self, archstring=None, name=None, bits=None):
#        self._obj_name = 'Register'
#        if check_type(archstring, str):
#            self.archstring = archstring
#        if check_type(name, str):
#            self.name = name
#        if check_type(bits, int):
#            self.bits = bits
#
#    def serialize(self):
#        serial_str = json.dumps([self._obj_name, json.dumps(self.__dict__)])
#        return serial_str
#
#    def deserialize(self, obj_data_str):
#        self.__dict__ = json.loads(obj_data_str)

def check_type(var, mytype):
    if var != None:
        if (not isinstance(var, mytype)):
            raise TypeError('Expect {}, got {}'.format(mytype, type(var)))
    return True

def load_config(package_name, config_name):
    res = pkgutil.get_data(package_name, 'config/{}.default'.format(config_name))
    path = os.path.join(os.path.expanduser('~'), '.config', package_name)
    if not os.path.exists(path):
        os.makedirs(path)
    path = os.path.join(path, config_name)
    if not os.path.exists(path):
        with open(path, 'wb') as f:
            f.write(res)
    config = configparser.ConfigParser()
    config.read(path)
    return config

